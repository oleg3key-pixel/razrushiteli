<?
include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';

include './system/h.php';



$id = _string(_num($_GET['id']));

if(!$id && $user) {
    $id = $user['id'];
}

  $i = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
  $i = mysql_fetch_array($i);








echo '  <div class="ribbon mb2">
   <div class="rl">
    <div class="rr">
      Доблесть
    </div>
   </div>
  </div> 
  <div class="bdr bg_blue mb2 lyell">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="mt10 mlr10 mb5 win">
             Текущий сезон 
           </div> 
           <div class="mlr10 pb5"> 
            <span class="lorange">Ваш уровень доблести:</span> '.$user['valor'].'
            <div class="mb2"></div> 
            <span class="lorange">Ваши очки доблести:</span> '.$user['valor_exp'].' из '.n_f(valor_exp($i['valor'])).'
            <div class="mb2"></div> 
            <span class="lorange">Бонус к опыту:</span> + '.$user['valor_b_exp'].'%
            <div class="mb2"></div> 
            <span class="lorange">Бонус к серебру:</span> + '.$user['valor_b_exp'].'%
            <div class="mb2"></div> 
           </div> 
           <div class="mlr10 mb5 pb5"> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div> 
  <div class="bdr bg_blue mb2 lyell">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="mt10 mlr10 mb10 lyell"> 
            <b><span style="color: #7AFE4E;">Доблесть</span></b> - показывает силу воина в боях и его боевой опыт, а также даёт бонус к опыту и серебру. 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div> 
   <div>
    <div></div>
   </div>
  </div> ';








include ('./system/f.php');


