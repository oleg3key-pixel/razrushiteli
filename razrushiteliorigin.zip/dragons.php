<?
include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';

include './system/h.php';












echo '
<div class="bdr cnr bg_green"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
			<div class="fl ml5 mt5 mr10 mb5">
				<img src="/images/drago/1.png">
			</div>
			<div class="ml100 mt5 mb2 mlr10 lwhite large">
				Зелёный дракон			</div>
			<div class="ml100 mb2 mlr10 lorange small">
								
							</div>
					<div class="clb"></div>
		</div></div></div></div></div></div></div></div></div>
		
		<div class=cntr><a href="/dragon1" class="ubtn mb2 green_no inbl"><span class="ul"><span class="ur">Войти в портал</span></span></a></div>
		
<div class="bdr cnr bg_green"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
			<div class="fl ml5 mt5 mr10 mb5">
				<img src="/images/drago/2.png">
			</div>
			<div class="ml100 mt5 mb2 mlr10 lwhite large">
				Синий дракон			</div>
			<div class="ml100 mb2 mlr10 lorange small">
								
							</div>
					<div class="clb"></div>
		</div></div></div></div></div></div></div></div></div>

		<div class=cntr><a href="/dragon2" class="ubtn mb2 green_no inbl"><span class="ul"><span class="ur">Войти в портал</span></span></a></div>

<div class="bdr cnr bg_green"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
			<div class="fl ml5 mt5 mr10 mb5">
				<img src="/images/drago/3.png">
			</div>
			<div class="ml100 mt5 mb2 mlr10 lwhite large">
				Красный дракон			</div>
			<div class="ml100 mb2 mlr10 lorange small">
								
							</div>
					<div class="clb"></div>
		</div></div></div></div></div></div></div></div></div>

		<div class=cntr><a href="/dragon3" class="ubtn mb2 green_no inbl"><span class="ul"><span class="ur">Войти в портал</span></span></a></div>

<div class="bdr cnr bg_green"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
			<div class="fl ml5 mt5 mr10 mb5">
				<img src="/images/drago/4.png">
			</div>
			<div class="ml100 mt5 mb2 mlr10 lwhite large">
				Черный дракон			</div>
			<div class="ml100 mb2 mlr10 lorange small">
								
							</div>
					<div class="clb"></div>
		</div></div></div></div></div></div></div></div></div>

		<div class=cntr><a href="/dragon4" class="ubtn mb2 green_no inbl"><span class="ul"><span class="ur">Войти в портал</span></span></a></div>

<div class="bdr cnr bg_green"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
			<div class="fl ml5 mt5 mr10 mb5">
				<img src="/images/drago/5.png">
			</div>
			<div class="ml100 mt5 mb2 mlr10 lwhite large">
				Золотой дракон			</div>
			<div class="ml100 mb2 mlr10 lorange small">
								
							</div>
					<div class="clb"></div>
		</div></div></div></div></div></div></div></div></div>

		<div class=cntr><a href="/dragon5" class="ubtn mb2 green_no inbl"><span class="ul"><span class="ur">Войти в портал</span></span></a></div>

<div class="bdr cnr bg_green"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
			<div class="fl ml5 mt5 mr10 mb5">
				<img src="/images/drago/6.png">
			</div>
			<div class="ml100 mt5 mb2 mlr10 lwhite large">
				Бриллиантовый дракон			</div>
			<div class="ml100 mb2 mlr10 lorange small">
								
							</div>
					<div class="clb"></div>
		</div></div></div></div></div></div></div></div></div>
		
				<div class=cntr><a href="/dragon6" class="ubtn mb2 green_no inbl"><span class="ul"><span class="ur">Войти в портал</span></span></a></div>

		';








include ('./system/f.php');


