<?
include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';

include './system/h.php';



$id = _string(_num($_GET['id']));

if(!$id && $user) {
    $id = $user['id'];
}
$zayavs = mysql_fetch_assoc(mysql_query("SELECT * FROM `clans_z` WHERE `user`='".$user['id']."' ")); 

  $i = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
  $i = mysql_fetch_array($i);
if($_GET['clans_z_1'] == true) {
mysql_query('INSERT INTO `clans_z` (`user`, `zayavs`, `clicks`) SELECT "'.$user['id'].'", "1", "1" LIMIT 1');
echo'<div class="bntf"><div class="small"><div class="nl"><div class="nr cntr lyell small lh1 plr15 pt5 pb5 sh">Заявка отправлена. Ожидайте приглашений.</div></div></div></div>
<div class="hr_g mb2 mt10">
   <div>
    <div></div>
   </div>
  </div><a class="mbtn mb2" href="/v_clans.php"><img class="icon" src="http://144.76.127.94/view/image/icons/back.png"> Назад в кланы!</a>';
include './system/f.php';
exit;
}

if($_GET['clans_z_2'] == true) {
mysql_query('DELETE FROM `clans_z` WHERE `user` = "'.$user['id'].'"');
echo'<div class="bntf"><div class="small"><div class="nl"><div class="nr cntr lyell small lh1 plr15 pt5 pb5 sh">Заявка отклонена.</div></div></div></div>
<div class="hr_g mb2 mt10">
   <div>
    <div></div>
   </div>
  </div><a class="mbtn mb2" href="/v_clans.php"><img class="icon" src="http://144.76.127.94/view/image/icons/back.png"> Назад в кланы!</a>';
include './system/f.php';
exit;
}
echo '<div class="ribbon mb2"><div class="rl"><div class="rr">Кланы</div></div></div>';

?>
<div class="bdr bg_green"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="mt5 mb10 mlr10 sh small cntr lyell">
		<span class="small">Кланы помогут тебе прокачивать своего героя быстрее, а так же дадут особые бонусы</span>	</div>
	<div class="mt5 mb10 mlr10 cntr">
		<img src="http://144.76.127.94/view/image/item/herb1.png" alt=""> <img src="http://144.76.127.94/view/image/item/herb3.png" alt=""> <img src="http://144.76.127.94/view/image/item/herb5.png" alt="">
	</div>
	<div class="mt5 mb10 mlr10 sh small cntr">
		<span class="small">Если вы хотите вступить в уже существующий клан, подайте заявку и вас пригласят.	</span></div>
</div></div></div></div></div></div></div></div></div><br>
<?
if($zayavs['clicks'] == 0){
echo '<div class="cntr mb5"><a class="ubtn inbl mt-15 green mb2" href="?clans_z_1=true"><span class="ul"><span class="ur">Хочу в клан!</span></span></a></div>';
}else{
echo '<div class="cntr mb5"><a class="ubtn inbl mt-15 red mb2" href="?clans_z_2=true"><span class="ul"><span class="ur">Отменить запрос!</span></span></a></div>';
}
?>
<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="mt5 mb10 mlr10 sh small cntr">
		<span class="small">Либо выберите его из списка и оставьте заявку на странице клана</span>	</div>
</div></div></div></div></div></div></div></div></div><br>
<?
echo '<div class="cntr mb5"><a class="ubtn inbl mt-15 blue mb2" href="/clans.php"><span class="ul"><span class="ur">Рейтинг кланов</span></span></a></div>';




?>
<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div cl="" ass="wr6"><div class="wr7"><div class="wr8">
	<div class="mt5 mb10 mlr10 sh small cntr">
		<span class="small">Либо создайте свой клан и станьте его Лидером</span>	</div>
</div></div></div></div></div></div></div></div></div><br>
<?

echo '<div class="cntr mb5"><a class="ubtn inbl mt-15 blue mb2" href="/clans/create"><span class="ul"><span class="ur">Создать клан</span></span></a></div>';





include ('./system/f.php');


