<?

include './system/common.php';

include './system/functions.php';

include './system/user.php';

if(!$user OR $user['access']==0) {

header('location: /');

exit;

}

switch($_GET['action']) {
default:

$title = 'Панель';

include './system/h.php';

include './adm _n.php';
?><div class='text2151'>
<?
$password = '14689533465855720648';

if($user[adm_password] != $password) {

?>
<div class="dot-line"></div>
<div class="block_zero">
<form action="?go=go" method="post">
<br><center>Ведите пароль от админки</center>
<center> <input type="text" name="passs" size="40" maxlength="40" class="text"> </center>

<br>
<center><span class="btn"><span class="end">
<input class="label" class="text medium-text" type="submit" value="Перейти">Перейти</span></span></form></div></center>

<?
}
?>
<?
$adm_pass = _string($_POST[passs]);
if($_GET[go]==go) {
mysql_query("UPDATE `users` SET `adm_password` = ".$adm_pass." WHERE `id` = ".$user[id]."");
header('location:?');
}
?>
<?
if($user[adm_password]==$password){
?>
<center>
<div class="ribbon mb2"><div class="rl"><div class="rr">Добро пожаловать</div></div></div>
<?
if($user['access'] >= 1) { echo '<a class="mbtn mb2" href="/adm/clon/">Проверка на мультоводство</a>';}
if($user['access'] >= 4) { echo '<a class="mbtn mb2" href="/adm/acc/">Редактор игроков</a>';}
if($user['access'] >= 4) { echo '<a class="mbtn mb2" href="/adm/ber/">Редактор кланов</a>';}
?>
</center>
<?

}
include './system/f.php';

break;
case 'news':

$title = 'Добавить новость';

include './system/h.php';
?>

<div class='title'><?=$title?></div>
<div class='line'></div>
<div class='content'>

<?


if(isset($_GET['add'])){

$name=$_POST['name'];
$text=$_POST['text'];

mysql_query("INSERT INTO `news` (`name`,`text`,`user`,`time`) VALUES ('$name','$text','".$user['id']."','".time()."')");
mysql_query("DELETE FROM `news_go` WHERE 1");


header('location: /');
}



?>


<form action="?add" method="post">
<p>Заголовок: <input type="text" name="name" /></p>
<p>Описание: <input type="text" name="text" /></p>
<p><input type="submit" value='Добавить!'/></p>
</form>
<br>



</div>



<?

include './system/f.php';

break;
case 'dxp':

if($user['access'] < 6) {
header('location: http://btvar.ru/adm/dxp/');
exit;
}

$title = 'Двойной опыт';

include './system/h.php';

if($_GET['sub']) mysql_query('UPDATE `dxp` SET `pos` = "'._num($_GET['dxp']).'"');

?>


<div class='title'><?=$title?></div>
<div class='line'></div>
<div class='content'>

<form action="" method="get">
<select name="dxp">
<option value="0">Выключить</option>
<option value="1">Включить</option>
</select>
<input class="label" name="sub" value="Применить" type="submit">
</form>
</div>






<?

include './system/f.php';

break;




  
  
  
  
  
  

case 'clon':

$title = 'Проверка на мультоводство';

include './system/h.php';

?>

<div class='block_zero'>

<?

$id = _string(_num($_POST['id']));
if($id) {
$users = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
$users = mysql_fetch_array($users);

if(!$users) {
header('location: /adm/clon/');
exit;
}

$count = mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `ip` = "'.$users['ip'].'" AND `id` != "'.$users['id'].'"'),0);

?>
IP: <?=$users['ip']?> [<?=$users['ua']?>]<br/>
</div>
<div class='dot-line'></div>
<div class='block_zero'>


<?

if($count > 0) {

$q = mysql_query('SELECT * FROM `users` WHERE `ip` = "'.$users['ip'].'" AND `id` != "'.$users['id'].'"');

while($row = mysql_fetch_array($q)) {

?>

<img src='/images/icon/race/<?=$row['r']?>.png' alt='*'/> <a href='/user/<?=$row['id']?>/'><?=$row['login']?></a><br/>

<?

}

}
else
{

?>

<font color='#999'>Персонажей нет!</font>

<?

}

}
else
{

?>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">
	    
  <form class='center' action='/adm/clon/' method='post'>
    ID персонажа:<br/><input class='text medium-text' name='id'/><br/>
    <input class="ibtn w90px" name='submit' type="submit" value=Найти>

  </form>
</div>
	<div class="clb"></div>
</div></div></div></div></div></div></div></div></div>
<?

  }

?>

</div>


<?

include './system/f.php';

  break;





  case 'pay':

  if($user['access'] < 6) {

    header('location: /adm/');

  exit;

  }
if($user['adm_password']!= '14689533465855720648') {
header('location: /adm/');
exit;
}
include './system/f.php';

  break;


  case 'unitpay': 

  if($user['access'] < 6) { 

    header('location: /adm/'); 

  exit; 

  }  

include './system/f.php';

  break;

  case 'unitpay':

  if($user['access'] < 6) {

    header('location: /adm/');

  exit;

  }

    $title = 'Пополнения';    

include './system/h.php';
if($user['adm_password']!= '14689533465855720648') {
header('location: /adm/');
exit;
}

    $max = 10;
  $count = mysql_result(mysql_query('SELECT COUNT(*) FROM `unitpay_payments`'),0);
  $pages = ceil($count/$max);
   $page = _string(_num($_GET['page']));

    if($page > $pages) {
    
   $page = $pages;
    
    }
  
    if($page < 1) {
    
   $page = 1;
    

    }
    


  $start = $page * $max - $max;

if($count > 0) {

?>

<div class='block_zero'>
 <table width='100%' cellpadding='0' cellspacing='0'>
  <tr>
  <td width='30%'>Имя персонажа<td>
  <td width='30%'>Сумма</td>
  <td>Статус</td>
 </tr></table>
<?

$q = mysql_query('SELECT * FROM `unitpay_payments` ORDER BY `id` DESC LIMIT '.$start.', '.$max.'');

  while($row = mysql_fetch_array($q)) {

  $account = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$row['account'].'"');
  $account = mysql_fetch_array($account);


?>

<table width='100%' cellpadding='0' cellspacing='0'>
  <tr>
  <td width='30%'><img src='/images/icon/race/<?=$account['r'].($account['online'] > time() - 300 ? '':'-off')?>.png' alt='*'/> <a href='/user/<?=$account['id']?>/'><?=$account['login']?></a></td>
  <td width='30%'><?=number_format($row['sum'], 2, '.', '')?> руб.</td>
  <td><?=($row['status'] == 0 ? '<font color=\'#c06060\'>Ошибка</font>':'<font color=\'#3c3\'>Успешно</font>')?></td>
 </tr></table>

<?

  }

?>

<?=pages('/adm.php?action=unitpay&')?>

</div>

<?

}
else
{

?>

<?

}


include './system/f.php';

  break;

  case 'deposit':

if($user['id'] > 1) {

    header('location: /adm/');

  exit;

  }
if($user['adm_password']!= '14689533465855720648') {
header('location: /adm/');
exit;
}
    $title = 'Передача средств';    

include './system/h.php';

  if($_POST['submit']) {

  $id = _string(_num($_POST['id']));
    
  $users = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
  $users = mysql_fetch_array($users);

  if($users) {
  
           $type = _string($_POST['type']);
    $count= _string(_num($_POST['count']));
  
  if(mysql_query('UPDATE `users` SET `'.$type.'` = `'.$type.'` + '.$count.' WHERE `id` = "'.$id.'"')) {

?>

<div class='ok' align='center'><img src='/images/icon/ok.png'> Перевод успешно выполнен!</div>

<?
  }
  else
  {
  
  }

  }
  else
  {
  
  
  }
  
  }

?>

<div class='block_zero center'>

  <form action='/adm/deposit/' method='post'>
    ID персонажа:<br/><input class='text medium-text' name='id'/><br/>
    <select name='type'>
    <option value='s'>Серебро</option>
    <option value='g'>Золото</option>
    </select>
    <br/><input class='text medium-text' name='count' size='2' value='0'/><br/>
<span class='btn'><span class='end'><input class='label' type='submit' name='submi' value='Перевести'/>Перевести</span></span>
  </form>

</div>

<?

include './system/f.php';

  break;

  case 'trade':

if($user['id'] < 1) {

    header('location: /adm/');

  exit;

  }

    $title = 'Передача вещей';    

include './system/h.php';
if($user['adm_password']!= '14689533465855720648') {
header('location: /adm/');
exit;
}

  if($_POST['submit']) {

  $id = _string(_num($_POST['id']));
$item = _string(_num($_POST['item']));


  $users = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
  $users = mysql_fetch_array($users);

   $item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$item.'"');
   $item = mysql_fetch_array($item);

  switch($item['quality']) {
    case 0:
  $bonus = 0;
    $str =28;
    $vit =28;
    $agi =28;
    $def =28;
     break;
    case 1:
  $bonus = 5;
    $str =31;
    $vit =31;
    $agi =31;
    $def =31;

     break;

    case 2:
 $bonus = 10;
    $str =45;
    $vit =45;
    $agi =45;
    $def =45;

     break;

    case 3:
 $bonus = 10;
    $str =52;
    $vit =52;
    $agi =52;
    $def =52;

      break;

    case 4:
 $bonus = 10;
    $str =60;
    $vit =60;
    $agi =60;
    $def =60;

     break;
     
    case 5:
 $bonus = 10;
    $str =120;
    $vit =120;
    $agi =120;
    $def =120;

     break;

    case 6:
 $bonus = 10; 
    $str =170;
    $vit =170;
    $agi =170;
    $def =170;

     break;

  }

  if($users && $item) {
  
           $type = _string($_POST['type']);
    $count= _string(_num($_POST['count']));
  
  if(mysql_query('INSERT INTO `inv` (`user`,
                                     `item`,
                                    `bonus`,
                                     `_str`,
                                     `_vit`,
                                     `_agi`,
                                     `_def`) VALUES ("'.$users['id'].'",
                                                      "'.$item['id'].'",
                                                           "'.$bonus.'",
                                                             "'.$str.'",
                                                             "'.$vit.'",
                                                             "'.$agi.'",
                                                             "'.$def.'")')) {

?>

<div class='ok' align='center'><img src='/images/icon/ok.png'> Вещь успешно передана!</div>

<?  
  
  }
  else
  {
  
  }

  }
  else
  {
  
  
  }
  
  }

?>

<div class='block_zero center'>

  <form action='/adm/trade/' method='post'>
    ID персонажа:<br/><input class='text medium-text' name='id'/> <br>
    <select name='item'>
<?

    $q = mysql_query('SELECT * FROM `items` ORDER BY `id`');
while($row = mysql_fetch_array($q)) {

  switch($row['quality']) {
    case 0:
  $quality = 'П';
     break;
    case 1:
  $quality = 'О';

     break;

    case 2:
  $quality = 'Р';

     break;

    case 3:
  $quality = 'Э';

      break;

    case 4:
  $quality = 'Л';

     break;
     
    case 5:
  $quality = 'Б';

     break;

    case 6:
  $quality = 'С Б';
     break;

  }  
?>
      <option value='<?=$row['id']?>'><?=$row['id']?> / <?=$quality?> / <?=$row['name']?></option>
<?

  }

?>
  </select><br/>
    <span class='btn'><span class='end'><input class='label' type='submit' name='submit' value='Передать'/>Передать</span></span>
  </form>

</div>


<?

include './system/f.php';
break;
case 'acc':
if($user['access']<4) {
header('location: /adm/');
exit;
}
if($user['adm_password']!= '14689533465855720648') {
header('location: /adm/');
exit;
}
$title = 'Редактирование Игрока';
include './system/h.php';


    
    
    
if(isset($_GET['yes'])){
if($user['access'] >= 4) 
echo _string($_POST['login']);
mysql_query('UPDATE `users` SET 
`login` = \''._string($_POST['login']).'\', 
`email` = \''._string($_POST['email']).'\', 
`password` = \''._string($_POST['password']).'\', 
`ip` = \''._string($_POST['ip']).'\', 
`g` = '._string(_num($_POST['g'])).', 
`s` = '._string(_num($_POST['s'])).', 
`level` = '._string(_num($_POST['level'])).', 
`exp` = '._string(_num($_POST['exp'])).', 
`sex` = '._string(_num($_POST['sex'])).', 
`access` = '._string(_num($_POST['access'])).', 
`maze_kluch` = '._string(_num($_POST['maze_kluch'])).', 
`str` = '._string(_num($_POST['str'])).', 
`def` = '._string(_num($_POST['def'])).', 
`vit` = '._string(_num($_POST['vit'])).', 
`coliseum_rating` = '._string(_num($_POST['coliseum_rating'])).', 
`ability_1` = '._string(_num($_POST['ability_1'])).', 
`ability_2` = '._string(_num($_POST['ability_2'])).', 
`ability_3` = '._string(_num($_POST['ability_3'])).', 
`ability_4` = '._string(_num($_POST['ability_4'])).', 
`ability_5` = '._string(_num($_POST['ability_5'])).', 
`ability_6` = '._string(_num($_POST['ability_6'])).', 
`ability_7` = '._string(_num($_POST['ability_7'])).', 
`ability_8` = '._string(_num($_POST['ability_8'])).', 
`ability_9` = '._string(_num($_POST['ability_9'])).', 
`valor` = '._string(_num($_POST['valor'])).', 
`valor_exp` = '._string(_num($_POST['valor_exp'])).', 
`lair_boi` = '._string(_num($_POST['lair_boi'])).', 
`anketa_status` = \''._string($_POST['anketa_status']).'\', 
`anketa_name` = \''._string($_POST['anketa_name']).'\', 
`anketa_city` = \''._string($_POST['anketa_city']).'\', 
`anketa_anketa` = \''._string($_POST['anketa_anketa']).'\', 
`amulet` = '._string(_num($_POST['amulet'])).', 
`amulet_stat` = '._string(_num($_POST['amulet_stat'])).', 
`amulet_exp` = '._string(_num($_POST['amulet_exp'])).', 
`amulet_silver` = '._string(_num($_POST['amulet_silver'])).', 
`mailclosed` = '._string(_num($_POST['mailclosed'])).', 
`_str` = '._string(_num($_POST['_str'])).', 
`_def` = '._string(_num($_POST['_def'])).', 
`_vit` = '._string(_num($_POST['_vit'])).', 
`skill` = '._string(_num($_POST['skill'])).' 
WHERE `id` = '._string(_num($_GET['yes'])).' LIMIT 1');


mysql_query('UPDATE `arena` SET 
`attack` = '._string(_num($_POST['attack'])).'
WHERE `id` = '._string(_num($_GET['yes'])).' LIMIT 1');


mysql_query('UPDATE `clan_memb` SET 
`clan` = '._string(_num($_POST['clan'])).',
`rank` = '._string(_num($_POST['rank'])).',
`v` = '._string(_num($_POST['v'])).',
`plat` = '._string(_num($_POST['c_plat'])).',
`valor` = '._string(_num($_POST['c_valor'])).',
`exp` = '._string(_num($_POST['c_exp'])).'
WHERE `user` = '._string(_num($_GET['yes'])).' LIMIT 1');




header('location: /adm/acc/');
exit;
}
if(isset($_POST['submit']) & !empty($_POST['id'])){
$acc = mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = '._string(_num($_POST['id'])).' LIMIT 1'));
$arena = mysql_fetch_array(mysql_query('SELECT * FROM `arena` WHERE `user` = '._string(_num($_POST['id'])).' LIMIT 1'));
$memb = mysql_fetch_array(mysql_query('SELECT * FROM `clan_memb` WHERE `user` = '._string(_num($_POST['id'])).' LIMIT 1'));
$premium = mysql_fetch_array(mysql_query('SELECT * FROM `premium` WHERE `user` = '._string(_num($_POST['id'])).' LIMIT 1'));





?>
<div class="content">
<?
if($user['access'] >= 4) {
?>
<form action='/adm/acc/yes/<?=_string(_num($_POST['id']))?>/' method='post'>

<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mr10 sh cntr">
		    
<img src=http://144.76.125.123//view/image/icons/hero.png class=icon> <input type='text' name='login' value='<?=$acc['login']?>'/ size="25">
<br>
<img src=http://144.76.125.123/view/image/records/records.png class=icon> <input type='text' name='email' value='<?=$acc['email']?>'/ size="25">
<br>
<img src=http://144.76.125.123/view/image/icons/close_forum.png class=icon> <input type='text' name='password' value='<?=$acc['password']?>'/ size="25">
<br>
<img src=http://144.76.125.123/view/image/icons/chrome.png class=icon> <input type='text' name='ip' value='<?=$acc['ip']?>'/ size="15">
<br>
<br>
<img src=http://144.76.125.123/view/image/icons/hero_on_1.png class=icon> <input type='text' name='sex' value='<?=$acc['sex']?>'/ size="1">
<img src=http://144.76.125.123/view/image/icons/excl.png class=icon> <input type='text' name='access' value='<?=$acc['access']?>'/ size="1">
<br>
<br>
<img src=http://144.76.125.123/view/image/icons/gold.png class=icon> <input type='text' name='g' value='<?=$acc['g']?>'/ size="5">
<img src=http://144.76.125.123/view/image/icons/silver.png class=icon> <input type='text' name='s' value='<?=$acc['s']?>'/ size="5">
<img src=http://144.76.125.123/view/image/icons/keys.png class=icon> <input type='text' name='maze_kluch' value='<?=$acc['maze_kluch']?>' / size="5">
<br>
<br>
<img src=http://144.76.125.123/view/image/icons/up.png class=icon> <input type='text' name='level' value='<?=$acc['level']?>'/ size="3">
<img src=http://144.76.125.123/view/image/icons/expirience.png class=icon> <input type='text' name='exp' value='<?=$acc['exp']?>'/ size="6">
<br>
<br>
<img src=http://144.76.127.94/view/image/icons/strength.png class=icon> <input type='text' name='str' value='<?=$acc['str']?>'/ size="3">
<img src=http://144.76.127.94/view/image/icons/defense.png class=icon> <input type='text' name='def' value='<?=$acc['def']?>'/ size="3">
<img src=http://144.76.127.94/view/image/icons/health.png class=icon> <input type='text' name='vit' value='<?=$acc['vit']?>'/ size="3">
<br>
<br>
<img src=http://144.76.125.123/view/image/icons/coliseum.png class=icon> <input type='text' name='coliseum_rating' value='<?=$acc['coliseum_rating']?>'/ size="3">
<br>
<br>
<img src=http://144.76.127.94/view/image/icons/our.png class=icon> <input type='text' name='attack' value='<?=$arena['attack']?>'/ size="3">
<img src=http://144.76.127.94/view/image/icons/enemies.png class=icon> <input type='text' name='lair_boi' value='<?=$acc['lair_boi']?>'/ size="3">
<br>
<br
<img src=http://144.76.127.94/view/image/icons/up_valor.png class=icon> <input type='text' name='valor' value='<?=$acc['valor']?>'/ size="3">
<img src=http://144.76.127.94/view/image/icons/valor_exp.png class=icon> <input type='text' name='valor_exp' value='<?=$acc['valor_exp']?>'/ size="6">
<br>
<br>
<img src=http://144.76.127.94/view/image/icons/about.png class=icon> <input type='text' name='anketa_status' value='<?=$acc['anketa_status']?>'/ >
<br>
<img src=http://144.76.127.94/view/image/icons/name.png class=icon> <input type='text' name='anketa_name' value='<?=$acc['anketa_name']?>'/ >
<br>
<img src=http://144.76.127.94/view/image/icons/city.png class=icon> <input type='text' name='anketa_city' value='<?=$acc['anketa_city']?>'/ >
<br>
<img src=http://144.76.127.94/view/image/icons/anketa.png class=icon> <input type='text' name='anketa_anketa' value='<?=$acc['anketa_anketa']?>'/ >
<br>
<br>
<img src=http://144.76.127.94/view/image/icons/clan.png class=icon> <input type='text' name='clan' value='<?=$memb['clan']?>'/ size="3">
<img src=http://144.76.125.123/view/image/icons/clan_created.png class=icon> <input type='text' name='rank' value='<?=$memb['rank']?>'/ size="3">
<img src=http://144.76.127.94/view/image/icons/calendar.png class=icon> <input type='text' name='v' value='<?=$memb['v']?>'/ size="3"><br>
<img src=http://144.76.125.123/view/image/icons/expirience.png class=icon> <input type='text' name='c_exp' value='<?=$memb['exp']?>'/ size="18"><br>
<img src=http://144.76.125.123/view/image/icons/up_valor.png class=icon> <input type='text' name='c_valor' value='<?=$memb['valor']?>'/ size="1">
<img src=http://144.76.125.123/view/image/icons/diamond.png class=icon> <input type='text' name='c_plat' value='<?=$memb['plat']?>'/ size="1">
<br>
<br>
<img class=icon src=http://144.76.125.123/view/image/pvp_log/rage.png> <input type='text' name='ability_1' value='<?=$acc['ability_1']?>'/ size="3">
<img class=icon src=http://144.76.125.123/view/image/pvp_log/punch.png> <input type='text' name='ability_2' value='<?=$acc['ability_2']?>'/ size="3">
<img class=icon src=http://144.76.125.123/view/image/pvp_log/parry.png> <input type='text' name='ability_3' value='<?=$acc['ability_3']?>'/ size="3"><br>
<img class=icon src=http://144.76.125.123/view/image/pvp_log/block.png> <input type='text' name='ability_4' value='<?=$acc['ability_4']?>'/ size="3">
<img class=icon src=http://144.76.125.123/view/image/pvp_log/protect.png> <input type='text' name='ability_5' value='<?=$acc['ability_5']?>'/ size="3">
<img class=icon src=http://144.76.125.123/view/image/pvp_log/round_hit.png> <input type='text' name='ability_6' value='<?=$acc['ability_6']?>'/ size="3"><br>
<img class=icon src=http://144.76.125.123/view/image/pvp_log/dodge.png> <input type='text' name='ability_7' value='<?=$acc['ability_7']?>'/ size="3">
<img class=icon src=http://144.76.125.123/view/image/pvp_log/healing.png> <input type='text' name='ability_8' value='<?=$acc['ability_8']?>'/ size="3">
<img class=icon src=http://144.76.125.123/view/image/pvp_log/evasion.png> <input type='text' name='ability_9' value='<?=$acc['ability_9']?>'/ size="3">
<br>
<br>
<img src=http://144.76.125.123/view/image/icons/post.png class=icon>  <input type='text' name='mailclosed' value='<?=$acc['mailclosed']?>'/ size="1">
<br>
<br>
<img src=http://144.76.125.123/view/image/icons/amulet.png class=icon> <input type='text' name='amulet' value='<?=$acc['amulet']?>'/ size="1">
<input type='text' name='amulet_stat' value='<?=$acc['amulet_stat']?>'/  size="3">
<input type='text' name='amulet_exp' value='<?=$acc['amulet_exp']?>'/ size="3">
<input type='text' name='amulet_silver' value='<?=$acc['amulet_silver']?>'/ size="3">
<br>
<br>
<img src=http://144.76.125.123/view/image/icons/train.png class=icon> <input type='text' name='skill' value='<?=$acc['skill']?>'/ size="1">
<input type='text' name='_str' value='<?=$acc['_str']?>'/ size="3">
<input type='text' name='_def' value='<?=$acc['_def']?>'/ size="3">
<input type='text' name='_vit' value='<?=$acc['_vit']?>'/ size="3">
<br>
<br>
<input type='submit' name='submit' value='Изменить'/>
</form>
</div></div>
		<div class="clb"></div>
	</div></div></div></div></div></div></div></div>
	</div>
<?
}
?>
<?
}
else{
?>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">
	    
<form action='/adm/acc/' method='post'>
ID персонажа
<br/>
<? echo"<input value='".$_GET['red']."'  name='id'/>";?>
<br/>

<input class="ibtn w90px" name='submit' type="submit" value=Найти>

</form>
</div>
	<div class="clb"></div>
</div></div></div></div></div></div></div></div></div>
<?
}
include './system/f.php';
break;




case 'ber':
if($user['access']>= 4) {
header('location: /adm/');
exit;
}
if($user['adm_password']!= '14689533465855720648') {
header('location: /adm/');
exit;
}
$title = 'Редактирование Игрока';
include './system/h.php';


    
    
    
if(isset($_GET['yes'])){
if($user['access'] >=4) 
echo _string($_POST['name']);
mysql_query('UPDATE `clans` SET 
`name` = \''._string($_POST['name']).'\', 
`description` = \''._string($_POST['description']).'\', 
`gerb` = '._string(_num($_POST['gerb'])).' ,
`level` = '._string(_num($_POST['level'])).' ,
`valor` = '._string(_num($_POST['valor'])).' ,
`plat_drag` = '._string(_num($_POST['plat_drag'])).' ,
`exp` = '._string(_num($_POST['exp'])).' ,
`g` = '._string(_num($_POST['g'])).' ,
`s` = '._string(_num($_POST['s'])).' ,
`built_1` = '._string(_num($_POST['built_1'])).' ,
`built_2` = '._string(_num($_POST['built_2'])).' ,
`built_3` = '._string(_num($_POST['built_3'])).' ,
`built_4` = '._string(_num($_POST['built_4'])).' ,
`built_5` = '._string(_num($_POST['built_5'])).' ,
`built_6` = '._string(_num($_POST['built_6'])).' 
WHERE `id` = '._string(_num($_GET['yes'])).' LIMIT 1');





header('location: /adm/ber/');
exit;
}
if(isset($_POST['submit']) & !empty($_POST['id'])){
$acc = mysql_fetch_array(mysql_query('SELECT * FROM `clans` WHERE `id` = '._string(_num($_POST['id'])).' LIMIT 1'));





?>
<div class="content">
<?
if($user['access']== 4) {
?>
<form action='/adm/ber/yes/<?=_string(_num($_POST['id']))?>/' method='post'>

<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mr10 sh cntr">
		    
<img src=http://144.76.127.94/view/image/icons/clan.png class=icon> <input type='text' name='name' value='<?=$acc['name']?>'/ size="25">
<br>
<img src=http://144.76.127.94/view/image/icons/calendar.png class=icon> <input type='text' name='description' value='<?=$acc['description']?>'/ size="25">
<br>
<br>
<img src=/images/ico/gerb/herb<?=$acc['gerb']?>.png class=icon> <input type='text' name='gerb' value='<?=$acc['gerb']?>'/ size="1">
<br>
<br>
<img src=http://144.76.127.94/view/image/icons/up.png class=icon> <input type='text' name='level' value='<?=$acc['level']?>'/ size="3">
<img src=http://144.76.127.94/view/image/icons/up_valor.png class=icon> <input type='text' name='valor' value='<?=$acc['valor']?>'/ size="3">
<img src=http://144.76.127.94/view/image/icons/diamond.png class=icon> <input type='text' name='plat_drag' value='<?=$acc['plat_drag']?>'/ size="3">
<br>
<br>
<img src=http://144.76.127.94/view/image/icons/expirience.png class=icon> <input type='text' name='exp' value='<?=$acc['exp']?>'/ size="10">
<br>
<br>
<img src=http://144.76.127.94/view/image/icons/gold.png class=icon> <input type='text' name='g' value='<?=$acc['g']?>'/ size="8">
<img src=http://144.76.127.94/view/image/icons/silver.png class=icon> <input type='text' name='s' value='<?=$acc['s']?>'/ size="8">
<br>
<br>
<img src=http://144.76.127.94/view/image/builds/build1_1.png class=icon> <input type='text' name='built_1' value='<?=$acc['built_1']?>'/ size="3"><br>
<img src=http://144.76.127.94/view/image/builds/build2_1.png class=icon> <input type='text' name='built_2' value='<?=$acc['built_2']?>'/ size="3"><br>
<img src=http://144.76.127.94/view/image/builds/build3_1.png class=icon> <input type='text' name='built_3' value='<?=$acc['built_3']?>'/ size="3"><br>
<img src=http://144.76.127.94/view/image/builds/build4_1.png class=icon> <input type='text' name='built_4' value='<?=$acc['built_4']?>'/ size="3"><br>
<img src=http://144.76.127.94/view/image/builds/build5_1.png class=icon> <input type='text' name='built_5' value='<?=$acc['built_5']?>'/ size="3"><br>
<img src=http://144.76.127.94/view/image/builds/build6_1.png class=icon> <input type='text' name='built_6' value='<?=$acc['built_6']?>'/ size="3">
<<br>
<br>
<input type='submit' name='submit' value='Изменить'/>
</form>
</div></div>
		<div class="clb"></div>
	</div></div></div></div></div></div></div></div>
	</div>
<?
}
?>
<?
}
else{
?>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">
	    
<form action='/adm/ber/' method='post'>
ID клана
<br/>
<? echo"<input value='".$_GET['red']."'  name='id'/>";?>
<br/>

<input class="ibtn w90px" name='submit' type="submit" value=Найти>

</form>
</div>
	<div class="clb"></div>
</div></div></div></div></div></div></div></div></div>
<?
}
include './system/f.php';
break;





}
?>