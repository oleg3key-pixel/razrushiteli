<?
  
  session_start();
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}

switch($_GET['go']){
	default:

    $title = 'Поход кланов';    

include './system/h.php';



#Тут ясно всё
if (!$clan){
?>
<font color='#90b0c0'>Вы не состоите в клане!</font><br/>
<?
	include './system/f.php';
	exit;
}else{




#Заголовок
?>


<div class='main'></div>
<img src = 'http://od.tiwar.mobi/images/town/hd/clantournament.jpg'width='100%' alt '*'>

<?



#Если игрок погиб выкидываем
$death = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod WHERE user = '".$user['login']."' AND death = '1'"),0);
if ($death){
echo "<center><div class=\'block_zero\'> Вы погибли </center></div>";

$time_start_21 = mysql_query("SELECT * FROM clan_poxod_open WHERE clan = '".$clan['id']."'");	
$time_start_11 = mysql_fetch_array($time_start_21);
if ($time_start_11['time'] - time() <= 0){
	
	mysql_query("DELETE FROM clan_poxod_boss WHERE clan = '".$clan['id']."'");
	mysql_query("DELETE FROM clan_poxod_open WHERE clan = '".$clan['id']."'");
	mysql_query("DELETE FROM clan_poxod WHERE clan = '".$clan['id']."'");
	mysql_query("DELETE FROM clan_poxod_klon WHERE user = '".$user['id']."'");
	
	}

include './system/f.php';
exit;
}




#Если игрок пытается зайти, когда поход начался
$op = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod WHERE user = '".$user['login']."' "),0);
$op_1 = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_open WHERE clan = '".$clan['id']."' AND start = '1' "),0);
if (!$op && $op_1){
	echo "<center><div class=\'block_zero\'>Бой уже начался.</div></center>";
	include './system/f.php';
	
 exit;
}


#Если глава не начал регистрацию на поход
	$op_2 = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_open WHERE clan = '".$clan['id']."' AND start = '0' "),0);
	if (!$op_2){
	
 

}


#Проверяем кланы
$clan_poxod = mysql_fetch_array(mysql_query("SELECT * FROM clan_memb WHERE user = '".$user['id']."'"));



#Игрок присоединяется к клан походу
if($_GET['go'] == true && !$op) {
mysql_query("INSERT INTO clan_poxod SET user = '".$user['login']."', user_id = '".$user['id']."', clan = '".$clan_poxod['clan']."', death = '0', start = '0'");
mysql_query("UPDATE users SET c_poxod = '1' WHERE id = '".$user['id']."'");
header('location: /clanland');
}


#Определяем колличества игроков, которые идут на поход
$kol = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod WHERE clan = '".$clan_poxod['clan']."'"),0);	


#Проверяем, записался ли игрок на клан поход
if (!mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod WHERE user = '".$user['login']."' AND death = 0"),0)){
	
	echo '<div class = \'center\'><a class=\'btn\' href=\'/clanland/?go=true\'><span class=\'end\'><span class=\'label\'> Записаться на поход ['.$kol.']</a></span></span></div></div>';
}else{
	echo "<div class = \'block_zero\'><div class=\'dot-line\'></div><b><center>Вы успешно записались на клан поход.<br>Ожидайте начало боя [$kol]</center></b></div><br>";
	
	
	
	
	  
	
	if ($clan_memb['rank'] == 4){
		
	?>	
	<div class='separ'></div>
  <center><a class='btn' href='/clanland/?start_poxod=true'><span class='end'><span class='label'><img src='/images/icon/arrow.png' alt='*'/> Начать поход</a></span></span></center>
	<?
	
	
	if ($_GET['start_poxod'] == true && $clan_memb['rank'] == 4){
		
		mysql_query("UPDATE clan_poxod_open SET start = '1' WHERE clan = '".$clan['id']."'");
		$time_msg = 'Битва началась <br><a class=\'btn\' href=\"/clanland/"\><span class=\'end\'><span class=\'label\'>Присоедениться</a></span></span><br>';
		mysql_query("INSERT INTO clan_msg SET clan = '".$clan['id']."', user = '".$user['id']."', text = '".$time_msg."', time = '".time()."'");	
	}
	}
	
	
	#Если начался поход, перекидываем на бой
	$clan_poxod_open = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_open WHERE clan = '".$clan_poxod['clan']."' AND start = '1'"),0);
	if ($clan_poxod_open){
		header('location: /clanland/bitva/');
		
		
		#Если босса нет, создаём его
		$boss_prov = mysql_num_rows(mysql_query("SELECT * FROM clan_poxod_boss WHERE clan = '".$clan['id']."'"));
		if($boss_prov < 1){
		$t_1 = time()+10;
		mysql_query("INSERT INTO clan_poxod_boss SET 
											 clan = '".$clan['id']."',
											 hp = '10000',
											 max_hp = '10000',
											 sila = '100',
											 zashita = '87',
											 nagr = '500',
											 etap = '1',
											 time = '".$t_1."'");
											 }
	}
	
}	
}//Clan	
break;


case 'bitva':
session_start();
$title = 'Битва';
include './system/h.php';
if (!$clan){
?>
<font color='#90b0c0'>Вы не состоите в клане!</font><br/>
<?
	include './system/f.php';
	exit;
}else{





#Если игрок пытается зайти, когда поход начался
$op = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod WHERE user = '".$user['login']."' "),0);
$op_1 = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_open WHERE clan = '".$clan['id']."' AND start = '1' "),0);
if (!$op && $op_1){
	echo "Бой уже начался.<br>";
	include './system/f.php';
	exit;
}


#Если игрок не записался на поход
if (!$op){
	header('location: /clanland/');	
	exit;
}


#Если поход не существует или глава не начал его
$clan_poxod_open = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_open WHERE clan = '".$clan['id']."' AND start = '0'"),0);
if ($clan_poxod_open){
	header('location: /clanland/');
	exit;
}






#Если игрок погиб выкидываем
$death = mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod WHERE user = '".$user['login']."' AND death = '1'"),0);
if ($death){
echo "<div class=\'block_zero center\' погибли </div>";
include './system/f.php';
exit;
}



#Выводим босса 1-го этапа
$boss_1 = mysql_fetch_array(mysql_query("SELECT * FROM clan_poxod_boss WHERE clan = '".$clan['id']."'"));



#Создаём босса 2-го этапа
if (mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_boss WHERE hp <= '1' AND clan = '".$clan['id']."' AND etap = '1'"),0)){
	mysql_query("UPDATE clan_poxod_boss SET hp = '15000000', max_hp = '15000000', sila = '1000000', zashita = '1480000', nagr = '5000', etap = '2'
				 WHERE clan = '".$clan['id']."'");
				 ?>
				<center> <img src='/images/drago/dragon1_win.jpg' width='100% '' alt='*/'></center>
				 <?
	echo "Поздравляем, вы прошли 1-ый этап <center><a class='btn' href = '/clanland/bitva/'><span class='end'><span class='label'> Перейти во 2-ой этап</a></span></span></center>";
	include './system/f.php';
	exit;
}


#Создаём босса 3-го этапа
if (mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_boss WHERE hp <= '1' AND clan = '".$clan['id']."' AND etap = '2'"),0)){
	mysql_query("UPDATE clan_poxod_boss SET hp = '20000000', max_hp = '20000000', sila = '200000', zashita = '3500000', nagr = '25000', etap = '3'
				 WHERE clan = '".$clan['id']."'");
				 ?>
				 <center><img src='/images/drago/dragon2_win.jpg' width='100% '' alt='*/'></center>
				 <?
	echo "Поздравляем, вы прошли 2-ый этап <center><a class='btn' href = '/clanland/bitva/'><span class='end'><span class='label'>Перейти в 3-ий этап</a></span></span></center>";
	include './system/f.php';
	exit;
}


#Если убили всех босов
if (mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod_boss WHERE hp <= '1' AND clan = '".$clan['id']."' AND etap = '3'"),0)){
	mysql_query("DELETE FROM clan_poxod_log WHERE clan = '".$clan['id']."'");

 $memb_user = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$memb['user'].'"');
  $memb_user = mysql_fetch_array($memb_user);
	$nagr1 = mysql_query("SELECT * FROM clan_poxod WHERE clan = '".$clan['id']."' AND nagr = '0'");	
while ($nagr = mysql_fetch_array($nagr1)){
	mysql_query("UPDATE users SET g = g + 20000 WHERE login = '".$nagr['user']."'");
	mysql_query("UPDATE users SET cb = cb + 1 WHERE login ='".$nagr['user']."'");
	mysql_query("UPDATE clans SET g = g + 50000 WHERE id = '".$clan['id']."'");
	mysql_query("UPDATE clan_poxod SET nagr = '1' WHERE clan = '".$clan['id']."'");

}
				 ?>
				 <center><img src='/images/drago/dragon3_win.jpg' width='100% '' alt='*/'></center>
				 <?
				 	echo "<b><center>Поздравляем, все боссы убиты<br> Следующий поход будет доступен когда лидер начнет </center></b>";





					
$time_start_2 = mysql_query("SELECT * FROM clan_poxod_open WHERE clan = '".$clan['id']."'");	
$time_start_1 = mysql_fetch_array($time_start_2);
if ($time_start_1['time'] - time() <= 0){
	
	mysql_query("DELETE FROM clan_poxod_boss WHERE clan = '".$clan['id']."'");
	mysql_query("DELETE FROM clan_poxod_open WHERE clan = '".$clan['id']."'");
	mysql_query("DELETE FROM clan_poxod WHERE clan = '".$clan['id']."'");
	mysql_query("DELETE FROM clan_poxod_klon WHERE user = '".$user['id']."'");
	
	}	
	





	
	
	
	include './system/f.php';
	exit;	
}
	
	

		
	
echo "<div class = 'content'>";	
#Выводим картинки драконов
if ($boss_1['etap'] == 1){
$rand_at = rand(1000,3000);
?>
<center><img src='/images/drago/dragon1_nowin.jpg' width='100% alt='*/'></center>

<?
}

if ($boss_1['etap'] == 2){
$rand_at = rand(2000,4000);
?>
<center><img src='/images/drago/dragon2_nowin.jpg' width='100% alt='*/'></center>
<?
}


if ($boss_1['etap'] == 3){
$rand_at = rand(3000,5000);
?>
<center><img src='/images/drago/dragon3_nowin.jpg' width='100% alt='*/'></center>
<?
}



#Подчитываем и рисуем шкалу Жизни драконов
$hp_boss = round(100/($boss_1['max_hp']/$boss_1['hp']));
    if($hp_boss > 100) {
        $hp_boss = 100;       
}
?>

<center>
<div style='clear:both;'></div><div class='stat_bar'><div class='progress' style='width:<?=$hp_boss?>%'></div></div></center>
<?



#Сила атаки игрока
$atack = rand($user['str']/5.3,$user['str']/5.4);
$atack = round($atack);



#Если игрок умер, пишем в таблице
if ($user['hp'] <= 0){
	mysql_query("UPDATE clan_poxod SET death = '1' WHERE user = '".$user['login']."'");
	mysql_query("INSERT INTO clan_poxod_log SET user = '".$user['login']."', clan = '".$clan['id']."', text = '<font color = \"yellow\">Погиб в бою</b></font>', death = '1'");
}



#Атака на босса
if($_GET['atack'] == true && !$death){


$rand_us = mysql_fetch_array(mysql_query("SELECT * FROM clan_poxod WHERE clan = '".$clan['id']."' ORDER by RAND()"));

mysql_query("UPDATE clan_poxod_boss SET hp = hp - $atack WHERE clan = '".$clan['id']."'");
mysql_query("INSERT INTO clan_poxod_log SET user = '".$user['login']."', clan = '".$clan['id']."', text = '<font color = \"greed\">ударил босса на <b>$atack</b> урона</font>' ");
header('location: /clanland/bitva/');
}


#Босс атакует
if ($boss_1['time'] - time() <= 0){
$rand_us = mysql_fetch_array(mysql_query("SELECT * FROM clan_poxod WHERE clan = '".$clan['id']."' ORDER by RAND()"));

mysql_query("UPDATE clan_poxod_boss SET `time`=".(time()+10)." WHERE clan = '".$clan['id']."'");
mysql_query("UPDATE users SET hp = hp - ".$rand_at." WHERE login = '".$rand_us['user']."'");
mysql_query("INSERT INTO clan_poxod_log SET user = '".$rand_us['user']."', clan = '".$clan['id']."', text = '<font color = \"red\">получил от босса <b>$rand_at</b> урона</font>' ");
}


$klon_jit = mysql_num_rows(mysql_query("SELECT * FROM clan_poxod_klon WHERE user = '".$user['id']."'"));

if($_GET['klon'] == true && $klon_jit < 1){
	$klon_time = time()+60; //Время в секундах сколько будет жить клон
	$klon_udar = time()+2; //Время в секундах перерыв межды ударами
	mysql_query("INSERT INTO clan_poxod_klon SET user = '".$user['id']."', time = '".$klon_time."', time_udar = '".$klon_udar."', death = '0'");
	mysql_query("INSERT INTO clan_poxod_log SET user = '".$user['login']."', clan = '".$clan['id']."', text = '<font color = \"silver\">Создал клона</font>' ");
	header('location: /clanland/bitva/');
	
}



$klon_1_1 = mysql_query("SELECT * FROM clan_poxod_klon WHERE user = '".$user['id']."' AND death = '0'");
$klon_1 = mysql_fetch_array($klon_1_1);
$klon_2 = mysql_num_rows($klon_1_1);

if ($klon_1['death'] == 0 && $klon_2 >= 1){ 

if ($klon_1['time_udar'] - time() <= 0){
mysql_query("UPDATE clan_poxod_klon SET `time_udar`=".(time()+3)." WHERE user = '".$user['id']."'");
mysql_query("UPDATE clan_poxod_boss SET hp = hp - $atack WHERE clan = '".$clan['id']."'");


mysql_query("INSERT INTO clan_poxod_log SET user = '".$user['login']."', clan = '".$clan['id']."', text = '[Клон]<font color = \"red\">ударил босса на <b>$atack</b> урона</font>' ");
}


if ($klon_1['time'] - time() <=0){
	mysql_query("UPDATE clan_poxod_klon SET death = '1' WHERE user = '".$user['id']."'");
	mysql_query("INSERT INTO clan_poxod_log SET user = '".$user['login']."', clan = '".$clan['id']."', text = '<font color = \"blue\">Клон изчез</font>' ");
}
$klon_1['time']=$klon_1['time']-time();
if ($klon_1['time'] - time() < 60 && $klon_1['death'] == 0){
echo "Клону осталось жить $klon_1[time] сек";}
}




echo "</div>";
$who1 = mysql_query("SELECT * FROM clan_poxod WHERE clan = '".$clan['id']."'");
echo "<div class = 'xaract'>";
while ($who = mysql_fetch_array($who1)){
$hp_1 = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE login = '".$who['user']."'"));
	if (mysql_result(mysql_query("SELECT COUNT(*) FROM clan_poxod WHERE user = '".$who['user']."' AND clan = '".$clan['id']."' AND death = '1'"),0)){
		$hp_1['hp'] = 'Умер';
	}
	

	 echo "<small>$who[user] <img src='/images/icon/health.png'> $hp_1[hp]</font></small> | ";
	
	
}

echo "</div>";


#Выводим логи
$auto_log = mysql_num_rows(mysql_query("SELECT * FROM clan_poxod_log WHERE user = '".$rand_us['user']."'"));
$log1 = mysql_query("SELECT * FROM clan_poxod_log WHERE clan = '".$clan['id']."' ORDER BY `id` DESC LIMIT 10");
echo "<div class = 'center'> <b>Лог боя:</b><div class = 'separ'></div>";
while ($log = mysql_fetch_array($log1)){
	echo "<b><small>$log[user]</b> $log[text]</small><br>";
}
echo "</div>";


#Выводим кнопку атакавать
echo "<div class = 'main'>";
echo '<div class=\'block_zero\'><div class=\'dot-line\'></div></div><center><a class =\'btn\' href=\'/clanland/bitva/?atack=true\'><span class=\'end\'><span class=\'label\'>Атаковать</a></span></span></center>';
$kloni = mysql_num_rows(mysql_query("SELECT * FROM clan_poxod_klon WHERE user = '".$user['id']."'"));
if ($kloni <= 0){
echo '<div class=\'separ\'></div><center><a class=\'btn\'     href=\'/clanland/bitva/?klon=true\'><span class=\'end\'><span class=\'label\'>Вызвать клона</a></span></span></center>';}
echo "</div>";



}//Clan
break;



}//switch
include './system/f.php';
?>