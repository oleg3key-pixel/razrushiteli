<?

/**
 * @ XxxDIABLOxxX
 *
 * @ Create clanexpfight
 * 
 * @ Date 13.02.2017 15:03 
 */

foreach (['common','functions','user','h'] as $h) {
	  $title = 'Подземелье';
	  include './system/'.$h.'.php';
}

if(!$user) exit(header('location: /'));


	 /**
     * name - имя босса 
	 * hp - жизни босса
	 * gold нгарада за босса желательно не изменять если вы не понимаете как делить цены
	 */

	 
 $_mobs = array(
   
   'name' => array(1 => 'Огненный пёс', 2 => 'Рыцарь', 3 => 'Орк', 4 => 'Мыщь', 5 => 'Змей', 6 => 'Демон', 7 => 'Бесмертный', 8 => 'Треант', 9 => 'Пёс', 10 => 'Повелитель'),
   'hp' => array(1 => '25000', 2 => '50000', 3 => '100000', 4 => '200000', 5 => '300000', 6 => '500000', 7 => '700000', 8 => '800000', 9 => '1000000', 10 => '2000000', 11 => '0'),
   'gold' => array(1 => '300', 2 => '600', 3 => '900', 4 => '1200', 5 => '1500', 6 => '1800', 7 => '2100', 8 => '2400', 9 => '2700', 10 => '3000')
   
   
   );


$_hellworld = mysql_fetch_array(mysql_query("SELECT * FROM `clan_dungeon` WHERE `clan` = ".$clan['id'].""));
   if(!$_hellworld) {
	   mysql_query("INSERT INTO `clan_dungeon` SET `time_battle`=".(time() + 172800).", `time_mobs`=".(time() + 259200).", `clan` = ".$clan['id']."");
	   exit(header('Location: /clandungeon/'));
   }
   
   $_hellworld_user = mysql_fetch_array(mysql_query("SELECT * FROM `clan_dungeon_user` WHERE `clan` = ".$clan['id']." AND `user` = ".$user['id'].""));
   if(!$_hellworld_user) {
	   mysql_query("INSERT INTO `clan_dungeon_user` SET `clan` = ".$clan['id'].", `user` = ".$user['id']."");
   }
   
	 
	 
if(!$clan OR $clan['clandungeon'] == 0 OR $_hellworld['level'] > 10) {

  exit(header('location: /clan/'));
  
}

   
if($_hellworld['level'] < 11 && $_hellworld['hp'] <= 0) {
	   ?>
	   <div class="block">
<img src="/images/icon/2hit.png" alt="*"> Победа <img src="/images/icon/2hit.png" alt="*"><br />
<img src="/images/icon/rage.png" alt="*"> <font color='#9C9'>Монстр повержен!</font> <img src="/images/icon/rage.png" alt="*"><br />
<img src="/images/hellworld/chest-min.png" alt="*">
<div class="separator"></div>
<span class="yellow">Клан получил <img src="/images/icon/gold.png" alt=""> <span class="bold"><?=$_mobs['gold'][$_hellworld['level']];?></span> в казну!</span><div class="separ"></div><a class="btn" href="/clandungeon/">
<span class="end"><span class="label">В подземелье</span></span></a>
<div class="separator"></div>
<img src="/images/icon/premium.png" alt="*"> Лучшие по урону <img src="/images/icon/premium.png" alt="*">
<?

	mysql_query("UPDATE `clans` SET `g` = ".($clan['g'] + $_mobs['gold'][$_hellworld['level']])." WHERE `id` = ".$clan['id']."");
	mysql_query("UPDATE `clan_dungeon` SET `level` = ".($_hellworld['level'] + 1).", `hp` = ".$_mobs['hp'][($_hellworld['level'] + 1)].", `gold` = '0' WHERE `clan` = ".$clan['id']."");

	$q = mysql_query('SELECT * FROM `clan_dungeon_user` WHERE `clan` = '.$clan['id'].' ORDER BY `dmg` DESC LIMIT 3');
	
	  while($row = mysql_fetch_array($q)) {
		  
		  $i++;
		  
		    $_user = mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$row['user'].'"'));
?>
<br />
<img src="/images/icon/crys/1.png" alt="*"> <?=$i?>. <img src='/images/icon/race/<?=$_user['r'].($_user['online'] > (time() - 300) ? '':'-off');?>.png' alt='*'/>  
<a href="/user/<?=$_user['id'];?>/"><?=$_user['login'];?></a> <img src="/images/icon/rage.png" alt=""> <b><?=$row['dmg'];?></b>
<?
	}
	
	echo '</div>';
	
	   mysql_query("DELETE FROM `clan_dungeon_user` WHERE `clan` = ".$clan['id']."");
	   mysql_query("UPDATE `clan_dungeon` SET `level` = ".($_hellworld['level'] + 1).", `hp` = ".($_mobs['hp'][($_hellworld['level'] + 1)])." WHERE `clan` = ".$clan['id']."");
	  
include './system/f.php';
	  exit;
   }
   
 
?>

<style>

.life_bar{
	max-width:50%;
	border:#c90 solid 1px;
	margin:5px auto
}
.life_bar-green{
background-color:#393
}
.life_bar,.life_bar-green{
height:3px;
padding:0
}

</style>


<div class='title'><?=$title;?></div>
     <div class='line'></div>
     <div class='content'>  <img src='/images/icon/hellworld.png'> Подземелье <span style='float: right'> <img src='/images/icon/level.png'> <?=$_hellworld['level'];?></span>
	 </div>
	 <div class='block'>
	 <img src='/images/hellworld/quality/<?=$_hellworld['level'];?>.png'> <?=$_mobs['name'][$_hellworld['level']];?> <img src='/images/icon/vit.png'> <?=$_hellworld['hp'];?> <br />
	 
	 <div class="life_bar">
	 <div class="life_bar-green" style="width: <?=@round(100/($_mobs['hp'][$_hellworld['level']]) * $_hellworld['hp']);?>%"></div></div>
	 <?
	 if(isset($_GET['attack']) && $user['fight_duengeon_time'] < time()) {
		 
	$ability_1 = false; $ability_2 = false; $ability_3 = false; $ability_4 = false;
															
  $_ability = array(
  
  'a_1_bonus' => array(25, 25, 25, 30, 35, 40, 45, 45, 50, 55, 65, 65, 70, 75, 80, 85, 85, 90, 95, 100, 105, 105, 145, 165, 165),
  'a_1_chanse' => array(5, 5, 5, 5, 5, 5, 8, 8, 8, 8, 11, 11, 11, 11, 11, 14, 14, 14, 14, 14, 17, 17, 20, 23, 23),
  
  'a_3_bonus' => array(5,5,8,11,14,17,17,20,23,26,29,29,32,35,38,41,41,44,47,50,53,53,77,89,89),
  'a_3_crit_chanse' => array(5,5,5,5,5,5,7,7,7,7,7,9,9,9,9,9,11,11,11,11,11,13,15,17,17),
  'a_3_chanse' => array(20,20,20,20,20,20,25,25,25,25,25,30,30,30,30,30,35,35,35,35,35,40,45,50,50),
  
  );
  
  if($user['ability_1'] > 0) {
    if(mt_rand(0, 100) <= $_ability['a_1_chanse'][$user['ability_1']]) $ability_1 = true;
  }
  
  if($user['ability_3'] > 0) {
    if(mt_rand(0, 100) <= $_ability['a_3_chanse'][$user['ability_3']]) $ability_3 = true;
  }
  
																		
	$dmg += ceil (rand(($user['str']/6), ($user['str']/4)));
																		
	if ($ability_1 == true) $dmg += ceil (($dmg / 100) * $_ability['a_1_bonus'][$user['ability_1']]);
	
	$crit = $ability_1 == true ? (rand (1,2)*($user['agi']/100) + $_ability['a_3_crit_chanse'][$user['ability_3']]) : (rand (1,2) * ($user['agi']/100));
	
	if (mt_rand(0, 100) <= $crit) {   
	
	$dmg *= 2;
	
	if($ability_3 == 1) $dmg += ceil (($dmg/100) * $_ability['a_3_bonus'][$user['ability_3']]);								
	
	}

	echo '<img src="/images/icon/hit.png" alt="*">- '.$dmg.'<br />';
	
	if($_hellworld['gold'] < ($_mobs['gold'][$_hellworld['level']] / 2)) {
	mysql_query("UPDATE `clan_dungeon` SET `gold` = ".($_hellworld['gold'] + 4)." WHERE `clan` = ".$clan['id']."");
	mysql_query("UPDATE `clan` SET `g` = ".($clan['g'] + 4)." WHERE `clan` = ".$clan['id']."");
	}elseif($_hellworld['gold'] > ($_mobs['gold'][$_hellworld['level']] / 2)) {
		mysql_query("UPDATE `clan_dungeon` SET `gold` = ".($_mobs['gold'][$_hellworld['level']] / 2)." WHERE `clan` = ".$clan['id']."");
	}
	
	mysql_query("UPDATE `clan_dungeon` SET `hp` = ".($_hellworld['hp'] - $dmg)." WHERE `clan` = ".$clan['id']."");
	
	
		mysql_query("UPDATE `clan_dungeon_user` SET `dmg` = ".($_hellworld_user['dmg'] + $dmg)." WHERE `user` = ".$user['id']." AND `clan` = ".$clan['id']."");
	
	mysql_query("UPDATE `users` SET `fight_duengeon` = ".($user['fight_duengeon'] - 1)." WHERE `id` = ".$user['id']."");
	
	if($user['fight_duengeon'] < 2) {
			mysql_query("UPDATE `users` SET `fight_duengeon` = '10' WHERE `id` = ".$user['id']."");
			mysql_query("UPDATE `users` SET `fight_duengeon_time` = ".(time() + 25200)." WHERE `id` = ".$user['id']."");
	}
	
  if($ability_1 == true) echo ' <img src=\'/images/ability/1.'.$user['ability_1_quality'].'.png\' width=\'25px\' height=\'25px\' alt=\'*\'/> ';
  if($ability_3 == true) echo ' <img src=\'/images/ability/3.'.$user['ability_3_quality'].'.png\' width=\'25px\' height=\'25px\' alt=\'*\'/> ';

  }
  
   if($_hellworld['time_mobs'] < time()) {
	   
	   	mysql_query("UPDATE `clan_dungeon` SET `hp` = ".$_mobs['hp'][$_hellworld['level']].", `time_mobs` = ".(time() + 259200)." WHERE `clan` = ".$clan['id']."");
		
		exit(header('location: /clandungeon/'));

	   
   }
?>
	</div>
	  <div class='content' align='center'>
		 <table border="0" cellpadding="5" cellspacing="0" align="center">
		 <tbody><tr><td width="50px"></td>
		 <td width="100px" height="120px">
		 <img style="border:1px solid #9b8869" src="/images/hellworld/<?=$_hellworld['level'];?>.png" alt=""></td>
		 <td width="50px" style="padding-left:5px"><img src="/images/hellworld/chest-min.png" alt=""></td><td></td></tr></tbody></table>
		 <?
		 if($user['fight_duengeon_time'] > time()) {
			 
			 if(isset($_GET['buy']) && $user['g'] > 4) {
			  
			 mysql_query("UPDATE `users` SET `g` = ".($user['g'] - 5).", `fight_duengeon_time` = ".(time() - 35000)." WHERE `id` = ".$user['id']."");	
			  	exit(header('Location: /clandungeon/'));
			 }
			 
			 
			?>
</div>
<div class="mini-line"></div>
			<center>Удары закончились<br />
			+10 ударов через <?=_time(($user['fight_duengeon_time'] - time()))?><br />
			 <a class="btn" href="/clandungeon/?buy"><span class="end"><span class="label">Купить 10 ударов за <img src="/images/icon/gold.png" alt="*"> 5</span></span></a></center>
			<?			
		 }else{
		 ?>
</div>
<div class='mini-line'>	
<div class='content'>
	 <center><a class="btn" href="/clandungeon/?attack&<?=mt_rand(1234567,89101112);?>"><span class="end"><span class="label">Атаковать монстра</span></span></a></center></div></div>
		 <?
		 }
		 ?>
	 </div>
	 </div>
	 <div class='content' align='center'>
	 Осталось ударов: <img src="/images/icon/hit.png" alt="*"> <?=($user['fight_duengeon_time'] > time() ? '0' : ''.$user['fight_duengeon'].'');?>
	 </div>
	 <div class="mini-line"></div>
	 
	 
	 <div class='content' align='center'>
	 <?
	  $_time = round(($_hellworld['time_battle'] - time()) / 86400);
	  if($_time > 0) {
	 ?>
	 До конца боя: <?=$_time;?> д<?=($_time > 1 ? 'ня':'ень');?>.
	 <?
	 }else{
		 ?>
		 До конца боя:<?=_time(($_hellworld['time_battle'] - time()));?>
		 <?
	 }
	 ?>
	 <br />
 <div class='separator'></div>

	 <center><img src="/images/icon/crys/1.png" alt="*"> <b><font color='#9C9'>Награда</font></b>  <img src="/images/icon/crys/1.png" alt="*"></center>
	 
	  
	  <img src="/images/icon/gold.png" alt="*"> в казну клана: 
	  <img src="/images/icon/gold.png" alt="*"> <?=$_hellworld['gold'];?> из <?=($_mobs['gold'][$_hellworld['level']] / 2);?> <br />
	  <img src="/images/icon/gold.png" alt="*"> <?=$_mobs['gold'][$_hellworld['level']];?> за победу!</div>
	  <div class="mini-line"></div>
	  <div class='content' align='center'>
	  <img src="/images/icon/2hit.png" alt="*"> В бою <img src="/images/icon/2hit.png" alt="*"></div>
	  <div class="mini-line"></div>
	  <div class='content'>
	   <img src="/images/icon/crys/1.png" alt="*"><font color="#9C9">Награда</font><img src="/images/icon/gold.png" alt="*"> 4
	  </div><div class="dot-line"></div>
	  
<?	 
$max = 10;
$count = mysql_result(mysql_query('SELECT COUNT(*) FROM `clan_dungeon_user` WHERE `clan` = '.$clan['id'].''),0);
     $pages = ceil($count/$max);
	 
	 $page = _string(_num($_GET['page']));
	 
	 if($page > $pages) $page = $pages;
	 if($page < 1) $page = 1;
	 $start = $page * $max - $max;
	 if($page == 1) $i = $page - 1; elseif($page == 2) $i = ($page + 9); else $i = ($page * 10) - 9;
  

	$q = mysql_query('SELECT * FROM `clan_dungeon_user` WHERE `clan` = '.$clan['id'].' ORDER BY `dmg` DESC LIMIT '.$start.', '.$max.'');
	
	  while($row = mysql_fetch_array($q)) {
		  
		  $i++;
		  
		    $_user = mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$row['user'].'"'));
?>
<div class="content">
<?=$i+$start;?>. <img src='/images/icon/race/<?=$_user['r'].($_user['online'] > (time() - 300) ? '':'-off');?>.png' alt='*'/> 
<a href="/user/<?=$_user['id'];?>/"><?=$_user['login'];?></a> - <img src="/images/icon/rage.png" alt="*"> <?=$row['dmg'];?> урона</div>
<div class="dot-line"></div>
<?
	  }
?>

<div class="main">
<div class="content">
<?=pages('/rating/collector/?');?>

</div>
<div class="content"></div>
 <div class="mini-line"></div>
 <div class='main'>
</div></div><div class='main'><ul class='hint '>

<li>Если монстра не убить за 72 часа, его здоровье восстанавливается до 100%</li>
<li>10 бесплатных ударов доступны раз в 7 часов.</li></div>
<?

include './system/f.php';

?>