
var timer_s = window.setInterval('runServerTimeTimer()', 1000);

function format(value) {return (value == 0) ? '00' : (((value < 10) ? '0' : '') + value);} 
function renderTime() {var hours = Math.floor(time / 3600);var minutes = Math.floor((time / 60) % 60);
var seconds = time % 60;document.getElementById('time_s').innerHTML = (format(hours) + ':' + format(minutes) + ':' + format(seconds));} 
function runServerTimeTimer() {if (time >= 24 * 60 * 60) {time = 0;} else {time++;}renderTime();}

function sml(html) {
    var e = document.getElementById('text');
    if (e != null) {
        e.value += ' ' + html + ' ';
        e.focus();
    }
}

function smiles() {
    var e = document.getElementById('smiles');
    if (e != null) {
        if (e.style.display == 'block') e.style.display = 'none';
        else e.style.display = 'block';
    }
}

document.onkeydown = function(e) {
    if (e.keyCode == 9) {
smiles();
    }
}


function timer(times,id_class,time_kon,time_r,load) {
function renderTimer() {var hours = Math.floor(times / 3600);var minutes = Math.floor((times / 60) % 60);var seconds = times % 60;
if(hours<1){hours='';}else{hours+=' ч ';}if(minutes<1){minutes='';}else{minutes+=' м ';}if(time_kon - time_r<1){seconds='';}else{seconds+=' c ';}
if(time_kon<time_r){
if(typeof(load) != "undefined" && load ==1) { location.reload(); }
document.getElementById(id_class).innerHTML ='';
}else{
document.getElementById(id_class).innerHTML = (hours  + minutes + seconds);} 
}
function TimeTimer2() {times--;time_r++;renderTimer();}
TimeTimer2();
setInterval(TimeTimer2, 1000);
}
