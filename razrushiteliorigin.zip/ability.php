<?
include './system/common.php';
include './system/functions.php';
include './system/user.php';

if(!$user) {
header('location: /');   
exit;}


$title = 'Умения';    
include './system/h.php';  

$id = _string(_num($_GET['id']));

  if($id && $id != $user['id']) {
    
  $i = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
  $i = mysql_fetch_array($i);
    
  if(!$i) {  
header('location: /user/');
exit;}

}else{
$i = $user;
}

  function quality_color($i) {
  
    switch($i) {
case 0:
$color = "#908060";
break;

case 1:
$color = "#60c030";
break;

case 2:
$color = "#6090c0";
break;

case 3:
$color = "#c060f0";
break;

case 4:
$color = "#f06000";
break;


case 5:
$color = "#909090";
break;

case 6: 
$color = "#909090";
break;
}

return $color;
}







  function value($i) {
  
    switch($i) {
case 0:
$value = 'g';
break;
case 1:
$value = 's';
break;
case 2:
$value = 's';
break;
case 3:
$value = 's';
break;
case 4:
$value = 'g';
break;
case 5:
$value = 's';
break;
case 6:
$value = 's';
break;
case 7:
$value = 's';
break;
case 8:
$value = 'g';
break;
case 9:
$value = 's';
break;
case 10:
$value = 's';
break;
case 11:
$value = 's';
break;
case 12:
$value = 'g';
break;
case 13:
$value = 's';
break;
case 14:
$value = 's';
break;
case 15:
$value = 's';
break;
case 16:
$value = 'g';
break;
case 17:
$value = 's';
break;
case 18:
$value = 's';
break;
case 19:
$value = 's';
break;
case 20:
$value = 'g';
break;
case 21:
$value = 's';
break;
case 22:
$value = 's';
break;
case 23:
$value = 's';
break;
case 24:
$value = 'g';
break;
case 25:
$value = 's';
break;
case 26:
$value = 's';
break;
case 27:
$value = 's';
break;
case 28:
$value = 'g';
break;
case 27:
$value = 's';
break;
case 28:
$value = 'g';
break;
case 29:
$value = 's';
break;
case 30:
$value = 'g';
break;
case 31:
$value = 's';
break;
case 32:
$value = 'g';
break;
case 33:
$value = 's';
break;
case 34:
$value = 'g';
break;
case 35:
$value = 's';
break;
case 36:
$value = 'g';
break;
case 37:
$value = 's';
break;
case 38:
$value = 'g';
break;
case 39:
$value = 's';
break;
case 40:
$value = 'g';
break;
case 41:
$value = 's';
break;
case 42:
$value = 'g';
break;
case 43:
$value = 's';
break;
case 44:
$value = 'g';
break;
case 45:
$value = 's';
break;
case 46:
$value = 'g';
break;
case 47:
$value = 's';
break;
case 48:
$value = 'g';
break;
case 49:
$value = 's';
break;
case 50:
$value = 'g';
break;
case 51:
$value = 's';
break;
case 52:
$value = 'g';
break;
case 53:
$value = 's';
break;
case 54:
$value = 'g';
break;
case 55:
$value = 's';
break;
case 56:
$value = 'g';
break;
case 57:
$value = 's';
break;
case 58:
$value = 'g';
break;
case 59:
$value = 's';
break;
case 60:
$value = 'g';
break;
case 61:
$value = 's';
break;
case 62:
$value = 'g';
break;
case 63:
$value = 's';
break;
case 64:
$value = 'g';
break;
case 65:
$value = 's';
break;
case 66:
$value = 'g';
break;
case 67:
$value = 's';
break;
case 68:
$value = 'g';
break;
case 69:
$value = 's';
break;
case 70:
$value = 'g';
break;
case 71:
$value = 's';
break;
case 72:
$value = 'g';
break;
case 73:
$value = 's';
break;
case 74:
$value = 'g';
break;
case 75:
$value = 's';
break;
case 76:
$value = 'g';
break;
case 77:
$value = 's';
break;
case 78:
$value = 'g';
break;
case 79:
$value = 's';
break;
case 80:
$value = 'g';
break;
case 81:
$value = 's';
break;
case 82:
$value = 'g';
break;
case 83:
$value = 's';
break;
case 84:
$value = 'g';
break;
case 85:
$value = 's';
break;
case 86:
$value = 'g';
break;
case 87:
$value = 's';
break;
case 88:
$value = 'g';
break;
case 89:
$value = 's';
break;
case 90:
$value = 'g';
break;
case 91:
$value = 's';
break;
case 92:
$value = 'g';
break;
case 93:
$value = 's';
break;
case 94:
$value = 'g';
break;
case 95:
$value = 's';
break;
case 96:
$value = 'g';
break;
case 97:
$value = 'g';
break;
case 98:
$value = 's';
break;
case 99:
$value = 'g';

}
  
  return $value;
  
  }
    
  function cost($i) {
    switch($i) {
case 0:
$cost =  50;
break;
case 1:
$cost = 1000;
break;
case 2:
$cost = 1200;
break;
case 3:
$cost = 1600;
break;
case 4:
$cost = 100;
break;
case 5:
$cost = 2000;
break;
case 6:
$cost = 3200;
break;
case 7:
$cost = 4000;
break;
case 8:
$cost = 200;
break;
case 9:
$cost = 5000;
break;
case 10:
$cost = 6000;
break;
case 11:
$cost = 7000;
break;
case 12:
$cost = 400;
break;
case 13:
$cost = 8000;
break;
case 14:
$cost = 10000;
break;
case 15:
$cost = 12000;
break;
case 16:
$cost = 600;
break;
case 17:
$cost = 16000;
break;
case 18:
$cost = 20000;
break;
case 19:
$cost = 24000;
break;
case 20:
$cost = 1000;
break;
case 21:
$cost = 30000;
break;
case 22:
$cost = 36000;
break;
case 23:
$cost = 42000;
break;
case 24:
$cost = 1500;
break;
case 25:
$cost = 52000;
break;
case 26:
$cost = 64000;
break;
case 27:
$cost = 86000;
break;
case 28:
$cost = 1500;
break;
case 29:
$cost = 116000;
break;
case 30:
$cost = 1500;
break;
case 31:
$cost = 150000;
break;
case 32:
$cost = 1500;
break;
case 33:
$cost = 180000;
break;
case 34:
$cost = 1500;
break;
case 35:
$cost = 210000;
break;
case 36:
$cost = 1500;
break;
case 37:
$cost = 250000;
break;
case 38:
$cost = 1500;
break;
case 39:
$cost = 500000;
break;
case 40:
$cost = 2000;
break;
case 41:
$cost = 1000000;
break;
case 42:
$cost = 2000;
break;
case 43:
$cost = 2000000;
break;
case 44:
$cost = 2000;
break;
case 45:
$cost = 4000000;
break;
case 46:
$cost = 2000;
break;
case 47:
$cost = 6000000;
break;
case 48:
$cost = 2000;
break;
case 49:
$cost = 8000000;
break;
case 50:
$cost = 2000;
break;
case 51:
$cost = 10000000;
break;
case 52:
$cost = 2000;
break;
case 53:
$cost = 15000000;
break;
case 54:
$cost = 2000;
break;
case 55:
$cost = 20000000;
break;
case 56:
$cost = 3000;
break;
case 57:
$cost = 30000000;
break;
case 58:
$cost = 3000;
break;
case 59:
$cost = 40000000;
break;
case 60:
$cost = 3000;
break;
case 61:
$cost = 60000000;
break;
case 62:
$cost = 3000;
break;
case 63:
$cost = 80000000;
break;
case 64:
$cost = 3000;
break;
case 65:
$cost = 100000000;
break;
case 66:
$cost = 4000;
break;
case 67:
$cost = 100000000;
break;
case 68:
$cost = 4000;
break;
case 69:
$cost = 100000000;
break;
case 70:
$cost = 4000;
break;
case 71:
$cost = 100000000;
break;
case 72:
$cost = 4000;
break;
case 73:
$cost = 100000000;
break;
case 74:
$cost = 4000;
break;
case 75:
$cost = 100000000;
break;
case 76:
$cost = 5000;
break;
case 77:
$cost = 200000000;
break;
case 78:
$cost = 6000;
break;
case 79:
$cost = 220000000;
break;
case 80:
$cost = 6000;
break;
case 81:
$cost = 250000000;
break;
case 82:
$cost = 6000;
break;
case 83:
$cost = 270000000;
break;
case 84:
$cost = 6000;
break;
case 85:
$cost = 300000000;
break;
case 86:
$cost = 6000;
break;
case 87:
$cost = 320000000;
break;
case 88:
$cost = 6000;
break;
case 89:
$cost = 350000000;
break;
case 90:
$cost = 6000;
break;
case 91:
$cost = 400000000;
break;
case 92:
$cost = 6000;
break;
case 93:
$cost = 450000000;
break;
case 94:
$cost = 6000;
break;
case 95:
$cost = 500000000;
break;
case 96:
$cost = 10000;
break;
case 97:
$cost = 10000;
break;
case 98:
$cost = 1000000000;
break;
case 99:
$cost = 25000;
break;
}
  
  return $cost;
   
  }

  
  
   if(isset($_GET['ability_1'])) {
if($user['ability_1'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_1'])] >= cost($user['ability_1'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_1']).'` = "'.($user[value($user['ability_1'])] - cost($user['ability_1'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_1` = "'.($user['ability_1'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `str` = "'.($user['str'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_1'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_1'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_1'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}

if(isset($_GET['ability_2'])) {
if($user['ability_2'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_2'])] >= cost($user['ability_2'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_2']).'` = "'.($user[value($user['ability_2'])] - cost($user['ability_2'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_2` = "'.($user['ability_2'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `str` = "'.($user['str'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_2'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_2'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_2'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}

if(isset($_GET['ability_3'])) {
if($user['ability_3'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_3'])] >= cost($user['ability_3'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_3']).'` = "'.($user[value($user['ability_3'])] - cost($user['ability_3'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_3` = "'.($user['ability_3'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `str` = "'.($user['str'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_3'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_3'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_3'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}






  
  if(isset($_GET['ability_4'])) {
if($user['ability_4'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_4'])] >= cost($user['ability_4'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_4']).'` = "'.($user[value($user['ability_4'])] - cost($user['ability_4'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_4` = "'.($user['ability_4'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `def` = "'.($user['def'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_4'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_4'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_4'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}

if(isset($_GET['ability_5'])) {
if($user['ability_5'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_5'])] >= cost($user['ability_5'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_5']).'` = "'.($user[value($user['ability_5'])] - cost($user['ability_5'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_5` = "'.($user['ability_5'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `def` = "'.($user['def'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_5'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_5'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_5'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}

if(isset($_GET['ability_6'])) {
if($user['ability_6'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_6'])] >= cost($user['ability_6'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_6']).'` = "'.($user[value($user['ability_6'])] - cost($user['ability_6'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_6` = "'.($user['ability_6'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `def` = "'.($user['def'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_6'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_6'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_6'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}





  
   if(isset($_GET['ability_7'])) {
if($user['ability_7'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_7'])] >= cost($user['ability_7'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_7']).'` = "'.($user[value($user['ability_7'])] - cost($user['ability_7'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_7` = "'.($user['ability_7'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `vit` = "'.($user['vit'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_7'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_7'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_7'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}  
  
  
   if(isset($_GET['ability_8'])) {
if($user['ability_8'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_8'])] >= cost($user['ability_8'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_8']).'` = "'.($user[value($user['ability_8'])] - cost($user['ability_8'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_8` = "'.($user['ability_8'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `vit` = "'.($user['vit'] + 10).'" WHERE `id` = "'.$user['id'].'"');

$_SESSION['ability_8'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_8'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_8'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}
  
if(isset($_GET['ability_9'])) {
if($user['ability_9'] < 100 && $i['id'] == $user['id']) {

    if($user[value($user['ability_9'])] >= cost($user['ability_9'])) {  	
mysql_query('UPDATE `users` SET `'.value($user['ability_9']).'` = "'.($user[value($user['ability_9'])] - cost($user['ability_9'])).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `ability_9` = "'.($user['ability_9'] + 1).'" WHERE `id` = "'.$user['id'].'"');
mysql_query('UPDATE `users` SET `vit` = "'.($user['vit'] + 10).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ability_9'] = mes('Успешно улучшено!');
header('location: /ability/'.$user['id'].'/');
exit;
  }else{
header('Location:/ability/'.$user['id'].'/');
$_SESSION['ability_9'] = mes('Недостаточно ресурсов!');
exit;           
  }
}else{}
$_SESSION['ability_9'] = mes('Невозможно улучшить!');
header('location: /ability/'.$user['id'].'/');
exit; 
}  
  
  
 echo '
  <div class="cntr lorange small mt-5"> 
   <span class="nowrap"> Ваши ресурсы: <img class="icon" src="http://144.76.127.94/view/image/icons/gold.png">21, <img class="icon" src="http://144.76.127.94/view/image/icons/silver.png">10.81k </span> 
  </div> 
  <div class="hr_arr2 mt10 mb10">
   <div class="alf">
    <div class="art">
     <div class="cntr small lyell">
       Атакующие умения 
     </div>
    </div>
   </div>
  </div> 
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10">
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/rage.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Ярость</a>
            <br> 
            <span><span class="text_small">Повышает ваш урон<br> Бонус: Сила</span></span>
            <br> 
            <span>Уровень: '.$i['ability_1'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_1'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/1/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_1']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_1']).'</span></span></a>';
}
echo '</div> 
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/punch.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Пробивание</a>
            <br> 
            <span><span class="text_small">Понижает вражескую броню<br> Бонус: Сила</span></span>
            <br> 
            <span>Уровень: '.$i['ability_2'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_2'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/2/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_2']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_2']).'</span></span></a>';
}
echo '</div> 
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/round_hit.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Круговой удар</a>
            <br> 
            <span><span class="text_small">Наносит урон нескольким целям<br> Бонус: Сила</span></span>
            <br> 
            <span>Уровень: '.$i['ability_3'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_3'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/3/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_3']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_3']).'</span></span></a>';
}
echo '</div> 
  <div class="hr_arr2 mt10 mb10">
   <div class="alf">
    <div class="art">
     <div class="cntr small lyell">
       Защитные умения 
     </div>
    </div>
   </div>
  </div> 
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/block.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Блок</a>
            <br> 
            <span><span class="text_small">Снижает получаемый урон<br> Бонус: Броня</span></span>
            <br> 
            <span>Уровень: '.$i['ability_4'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_4'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/4/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_4']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_4']).'</span></span></a>';
}
echo '</div> 
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/protect.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Защита</a>
            <br> 
            <span><span class="text_small">Повышает вашу броню<br> Бонус: Броня</span></span>
            <br> 
            <span>Уровень: '.$i['ability_5'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div> 
  </div>';
if($user['ability_5'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/5/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_5']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_5']).'</span></span></a>';
}
echo '</div> 
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/parry.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Парирование</a>
            <br> 
            <span><span class="text_small">Защищает от вражеской атаки<br> Бонус: Броня</span></span>
            <br> 
            <span>Уровень: '.$i['ability_6'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_6'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/6/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_6']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_6']).'</span></span></a>';
}
echo '</div> 
  <div class="hr_arr2 mt10 mb10">
   <div class="alf">
    <div class="art">
     <div class="cntr small lyell">
       Особые умения 
     </div>
    </div>
   </div>
  </div> 
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/dodge.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Уворот</a>
            <br> 
            <span><span class="text_small">Убирает вас из цели<br> Бонус: Здоровье</span></span>
            <br> 
            <span>Уровень: '.$i['ability_7'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_7'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/7/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_7']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_7']).'</span></span></a>';
}
echo '</div>  
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/healing.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Лечение</a>
            <br> 
            <span><span class="text_small">Исцеляет ваши раны<br> Бонус: Здоровье</span></span>
            <br> 
            <span>Уровень: '.$i['ability_8'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_8'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/8/" ><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_8']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_8']).'</span></span></a>';
}
echo '</div>  
  <div class="bdr bg_green">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="fl mt10"> 
            <a class="ml10" href="?"><img class="item_icon" src="http://144.76.127.94/view/image/train/evasion.png"></a> 
           </div> 
           <div class="ml68 mt10 mb10 mr10 sh small lorange"> 
            <a href="?" class="medium lwhite tdn">Уклонение</a>
            <br> 
            <span><span class="text_small">Спасает от вражеской атаки<br> Бонус: Здоровье</span></span>
            <br> 
            <span>Уровень: '.$i['ability_9'].'  из 100</span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
if($user['ability_9'] < 100     && $i['id'] == $user['id']) {
    echo '<br><div class="cntr"><a class="ubtn inbl mt-15 green mb2" href="/ability/'.$i['id'].'/9/"><span class="ul"><span class="ur"><img src="/images/ico/png/'.(value($user['ability_9']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_9']).'</span></span></a>';
}
echo '</div>  
  <div class="hr_g mb2">
   <div>
    <div></div>
   </div>
  </div> 
  <div class="bntf">
   <div class="small">
    <div class="nl">
     <div class="nr cntr lyell small lh1 plr15 pt5 pb5 sh">
       Боевые умения увеличивают параметры вашего героя и дают уникальные возможности в боях
     </div>
    </div>
   </div>
  </div> 
  <div class="hr_g mb2">
   <div>
    <div></div>
   </div>
  </div> 
  <a class="mbtn mb2" href="/user"><img src="http://144.76.127.94/view/image/icons/back.png" class="icon"> Назад к категориям</a>
   <div>
    <div></div>
   </div>
  </div> 
   <div>
    <div></div>
   </div>
  </div> ';
  
  




/*
echo' '.$_SESSION['ability_1'].' ';
    $_SESSION['ability_1']=NULL; //Удаляем сесию
echo'<div class="empty_block">
<table cellpadding="0" cellspacing="0">
<tr>
  <td width="15%"><img src="/images/ico/ability/1.png" alt="*"/></td>
  <td><font color="#fff">Ярость</font>
  <small><br/>
  <font color="#9bc">Бонус:</font> <font color="#9c9"> '.$a_1_bonus.'% </font> к урону<br/>
  <font color="#9bc">Шанс срабатывания:</font> <font color="#9c9"> '.$a_1_chanse.'% </font><br/>
  <font color="#9bc">Уровень:</font> <font color="#9c9">'.$i['ability_1'].' </font> из <font color="#9c9"> 24 </font> 
  </small></td>
  </tr></table>';

  



if($user['ability_1'] == 0     && $i['id'] == $user['id']) {
echo'<br/><div class="link_center">
<a href="/ability/'.$id.'/1/">Купить за <img src="/images/ico/png/gold.png" alt="*"/ width="18"> 100</a>
</div>';
}
elseif($user['ability_1'] < 24 && $i['id'] == $user['id']) {
echo'<br/><div class="link_center">
<a href="/ability/'.$i['id'].'/1/"> <img src="/images/ico/png/'.(value($user['ability_1']) == 'g' ? 'gold':'silver').'.png" alt="*"/ width="18"> '.cost($user['ability_1']).'</a>
</div>';
}
echo'</div><div class="line"></div>';

  



echo' '.$_SESSION['ability_2'].' ';
    $_SESSION['ability_2']=NULL; //Удаляем сесию
echo'<div class="empty_block">
<table cellpadding="0" cellspacing="0">
<tr>
  <td width="15%"><img src="/images/ico/ability/2.png" alt="*"/></td>
  <td> <font color="#fff">Блок</font>
  <small><br/>
  <font color="#9bc">Бонус:</font> <font color="#9c9">'.$a_2_bonus.'%</font> к урону врага<br/>
  <font color="#9bc">Шанс срабатывания:</font> <font color="#9c9">'.$a_2_chanse.'%</font><br/>
  <font color="#9bc">Уровень:</font> <font color="#9c9">'.$i['ability_2'].' </font> из <font color="#9c9"> 24 </font> 
  </small></td>
  </tr></table>';



if($user['ability_2'] == 0     && $i['id'] == $user['id']) {
echo'<div class="link_center">
<a href="/ability/'.$i['id'].'/2/">Купить за <img src="/images/ico/png/gold.png" alt="*" width="18"/> 100</a></div>';
}elseif($user['ability_2'] < 24 && $i['id'] == $user['id']){
echo'<div class="link_center">
<a href="/ability/'.$i['id'].'/2/"><img src="/images/ico/png/'.(value($user['ability_2']) == 'g' ? 'gold':'silver').'.png" alt="*" width="18"/> '.cost($user['ability_2']).'</a>
</div>';
}
echo'</div><div class="line"></div>';




echo' '.$_SESSION['ability_3'].' ';
    $_SESSION['ability_3']=NULL; //Удаляем сесию
echo'<div class="empty_block">
<table cellpadding="0" cellspacing="0">
<tr>
  <td width="15%"><img src="/images/ico/ability/3.png" alt="*"/></td>
  <td><font color="#fff">Лечение</font>
  <small><br/>
  <font color="#9bc">Бонус:</font> <font color="#9c9"> '.$a_3_bonus.'% </font> к урону крита <font color="#9c9"> '.$a_3_crit_chanse.'% </font> к шансу крита<br/>
  <font color="#9bc">Шанс срабатывания:</font> <font color="#9c9"> '.$a_3_chanse.'% </font> <br/>
    <font color="#9bc">Уровень:</font> <font color="#9c9">'.$i['ability_3'].' </font> из <font color="#9c9"> 24 </font> 
  </small></td>
  </tr></table>';



    if($user['ability_3'] == 0 && $i['id'] == $user['id']) {
echo'<div class="link_center">
<a href="/ability/'.$i['id'].'/3/">Купить за <img src="/images/ico/png/gold.png" alt="*" width="18"/> 100</a></div>';
}elseif($user['ability_3'] < 24 && $i['id'] == $user['id']) {
echo'<div class="link_center">
<a href="/ability/'.$i['id'].'/3/"><img src="/images/ico/png/'.(value($user['ability_3']) == 'g' ? 'gold':'silver').'.png" alt="*" width="18"/> '.cost($user['ability_3']).'</a>
</div>';
}
echo'</div><div class="line"></div>';

  





echo' '.$_SESSION['ability_4'].' ';
    $_SESSION['ability_4']=NULL; //Удаляем сесию
echo'<div class="empty_block">
<table cellpadding="0" cellspacing="0">
<tr>
  <td width="15%"><img src="/images/ico/ability/4.png" alt="*"/></td>
  <td> <font color="#fff">Защитная стойка</font>
  <small><br/>
  <font color="#9bc">Бонус:</font> <font color="#9c9">-'.$a_4_bonus.'%</font> снижение урона от крит удара<br/>
  <font color="#9bc">Шанс срабатывания:</font> <font color="#9c9">'.$a_4_chanse.'%</font><br/>
  <font color="#9bc">Уровень:</font> <font color="#9c9">'.$i['ability_4'].' </font> из <font color="#9c9"> 24 </font> 
</small></td></tr></table>';


if($user['ability_4'] == 0     && $i['id'] == $user['id']) {
echo'<div class="link_center">
<a href="/ability/'.$i['id'].'/4/">Купить за <img src="/images/ico/png/gold.png" alt="*" width="18"/> 100</a></div>';
}elseif($user['ability_4'] < 24 && $i['id'] == $user['id']){
echo'<div class="link_center">
<a href="/ability/'.$i['id'].'/4/"><img src="/images/ico/png/'.(value($user['ability_4']) == 'g' ? 'gold':'silver').'.png" alt="*" width="18"/> '.cost($user['ability_4']).'</a>
</div>';
}
echo'</div><div class="line"></div>';
*/


 

 
  
include './system/f.php';

?>