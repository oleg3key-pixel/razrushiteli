<?
include './system/common.php';
include './system/functions.php';
include './system/user.php';
$title='Ошибка';
include './system/h.php';  
echo'<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mr10 sh cntr">Запрос <a>'.$_SERVER['REQUEST_URI'].'</a> не может быть обработан на сервере!</div></div>
		<div class="clb"></div>
	</div></div></div></div></div></div></div></div>
	</div>';
include './system/f.php';  
?>
