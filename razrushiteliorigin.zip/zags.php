<?php
include './system/common.php';
include './system/functions.php';
include './system/user.php';
if(!$user) {
header('location: /');
exit;
}
if(isset($_GET['top'])){
$title = 'Топ пар';
include './system/h.php';
$max = 15;
$count = mysql_result(mysql_query('SELECT COUNT(*) FROM `zags` WHERE `status` = "da"'),0);
$pages = ceil($count/$max);
$page = _string(_num($_GET['page']));
if($page > $pages) {
$page = $pages;
}
if($page < 1) {
$page = 1;
}




  
  
  
  
$start = $page * $max - $max;
$q = mysql_query('SELECT * FROM `zags` WHERE `status` = "da" ORDER BY `id` DESC LIMIT '.$start.', '.$max.'');
echo "<div class='block_zero'>";
if($count == 0)echo "Нет пар<br>";
while($post = mysql_fetch_array($q)) {
$ank = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$post['id_0'].'"');
$ank = mysql_fetch_array($ank);
$ank2 = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$post['id_1'].'"');
$ank2 = mysql_fetch_array($ank2);










echo "<a href='/user/$ank[id]/'>$ank[login]</a> женат на <a href='/user/$ank2[id]/'>$ank2[login]</a>";
echo "<div class='dot-line'></div>";
}
pages('/zags/?top&');
echo "</div>";
include './system/f.php';
break;
}



$id = _string(_num($_GET['id']));

if(!$id && $user) {
    $id = $user['id'];
}

  $i = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
  $i = mysql_fetch_array($i);






$zags = mysql_query('SELECT * FROM `zags` WHERE `id_0` = "'.$user['id'].'" OR `id_1` = "'.$user['id'].'"');
$zags = mysql_fetch_array($zags);
if(!$zags and $user['sex'] == 0){
mysql_query('INSERT INTO `zags` SET `id_0` = "'.$user['id'].'", `status` = "off"');
header("Location: ?");
exit();
}
if(isset($_GET['noviz'])){
mysql_query('UPDATE `zags` SET `id_1` = "0", `status` = "off" WHERE `id` = "'.$zags['id'].'"');
$_SESSION['ok'] = 'Заявка отменина';
header("Location: /zags/?".rand(4999,5999));
exit();
}
if(isset($_GET['post'])){
if(isset($_POST['login'])){
$login = mysql_query('SELECT * FROM `users` WHERE `login` = "'.$_POST['login'].'"');
$login = mysql_fetch_array($login);
if(!$login)$err = 'Такой девушки не существует';
if($login['sex'] == 0)$err = 'Нельзя';
if($user['g'] < 0)$err = 'Не достатачно золота';
if(!$err){
mysql_query('UPDATE `zags` SET `id_1` = "'.$login['id'].'", `status` = "net"  WHERE `id` = "'.$zags['id'].'"');
mysql_query('UPDATE `users` SET `g` = "'.($user['g']-0).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['ok'] = 'Заявка успешно отправлена';
header("Location: /zags/?".rand(4999,5999));
exit();
}else{
$_SESSION['error'] = $err;
header("Location: /zags/?".rand(4999,5999));
exit();
}
}else{
$_SESSION['error'] = 'Введите ник жены';
header("Location: /zags/?".rand(4999,5999));
exit();
}
}
if(isset($_GET['vizok']) and $user['sex'] == 1){
mysql_query('UPDATE `zags` SET `status` = "da" WHERE `id` = "'.$_GET[vizok].'"');
$_SESSION['ok'] = 'Теперь вы замужняя';
header("Location: /zags/?".rand(4999,5999));
exit();
}
if(isset($_GET['vizno']) and $user['sex'] == 1){
mysql_query('UPDATE `zags` SET `status` = "off" WHERE `id` = "'.$_GET[vizno].'"');
$_SESSION['ok'] = 'Заявка отменена';
header("Location: /zags/?".rand(4999,5999));
exit();
}
if(isset($_GET['razvod']) and $zags['status'] == 'da'){
mysql_query('UPDATE `zags` SET `status` = "off" WHERE `id` = "'.$zags['id'].'"');
$_SESSION['ok'] = 'Теперь вы свободны';
header("Location: /zags/?".rand(4999,5999));
exit();
}
$title = 'Загс';
include './system/h.php';
if(isset($_SESSION['error'])){
echo "<div class='error center'> $_SESSION[error]</div>";
unset($_SESSION['error']);
}
if(isset($_SESSION['ok'])){
echo "<div class='ok center'> $_SESSION[ok]</div>";
unset($_SESSION['ok']);
}
$w = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$zags['id_1'].'"');
$w = mysql_fetch_array($w);
if($user['sex'] == 1){
$zags = mysql_query('SELECT * FROM `zags` WHERE `id_1` = "'.$user['id'].'" AND `status` = "da"');
$zags = mysql_fetch_array($zags);
if($zags){
$m = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$zags['id_0'].'"');
$m = mysql_fetch_array($m);
?>
<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mlr10 sh cntr">
Вы замужем за <a href=/user/<?=$m[id]?>/><?=$m[login]?></a>
	</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
	</div>
<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mlr10 sh cntr">

<br><br><div class="cntr"><a href="?razvod" class="ubtn inbl mt-15 red mb5"><span class="ul"><span class="ur">Развестись</span></span></a></div>
	</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
	</div>
<?
}else{
$max = 15;
$count = mysql_result(mysql_query('SELECT COUNT(*) FROM `zags` WHERE `id_1` = "'.$user['id'].'" AND `status` = "net"'),0);
$pages = ceil($count/$max);
$page = _string(_num($_GET['page']));
if($page > $pages) {
$page = $pages;
}
if($page < 1) {
$page = 1;
}
$start = $page * $max - $max;
$q = mysql_query('SELECT * FROM `zags` WHERE `id_1` = "'.$user['id'].'" AND `status` = "net" ORDER BY `id` DESC LIMIT '.$start.', '.$max.'');
echo "<div class='block_zero'>";
if($count == 0)echo "Заявок на свадьбу нет<br>";
while($post = mysql_fetch_array($q)) {
$ank = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$post['id_0'].'"');
$ank = mysql_fetch_array($ank);
?>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">
<a href='/user/$ank[id]/'><?=$ank[login]?></a> хочет на вас жениться...
	</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
	</div>
	<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr"><br>
	<div class="cntr"><a href="?vizok=<?=$post[id]?>" class="ubtn inbl mt-15 green mb5"><span class="ul"><span class="ur">Принять заявку</span></span></a></div><br>
	<div class="cntr"><a href="?vizno=<?=$post[id]?>" class="ubtn inbl mt-15 red mb5"><span class="ul"><span class="ur">Отклонить заявку</span></span></a></div>
		</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
<?
}

pages('/zags/?');
echo "</div>";
}
}else{
if($zags['status'] == 'da'){
?>
<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mlr10 sh cntr">
Вы женаты на: <a href='/user/<?=$w[id]?>/'><?=$w[login]?></a>
	</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
	</div>
<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mlr10 sh cntr">

<br><br><div class="cntr"><a href="?razvod" class="ubtn inbl mt-15 red mb5"><span class="ul"><span class="ur">Развестись</span></span></a></div>
	</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
	</div>
<?




}elseif($zags['status'] == 'off'){
    

?>




<div class=ribbon mb2><div class=rl><div class=rr>ЗАГС</div></div></div>



<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
<div class="ml10 mt5 mr10 mb5 cntr">
  
<div class=cntr>
<form action='?post' method='post'>Введите ник жены<br><input class='text medium-text' name='login' value='<?=$i[login]?>'><br><br>

<input class="ibtn w90px" type="submit" value=Отправить></span></span><br></div><div class="clb"></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
<?

echo "</form>";
}
if($zags[status] == 'net'){
echo '<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">';
echo "<a href='/user/$w[id]/'>$w[login]</a>, еще не принила вашу заявку...<br>
<div class=clb></div>
</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>";
?>
<div class="bdr bg_blue"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
		<div class="mt10 mb10 mlr10 sh cntr">

<br><br><div class="cntr"><a href="?noviz" class="ubtn inbl mt-15 red mb5"><span class="ul"><span class="ur">Отклонить</span></span></a></div>
	</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
	</div>
	<?
}

}
include './system/f.php';
?>