<?
include './system/common.php';
include './system/functions.php';
include './system/user.php';
include './system/h.php';
echo'  <div class="ribbon mb2">
   <div class="rl">
    <div class="rr">
      Акция
    </div>
   </div>
  </div> 
<div class="bdr bg_blue cntr">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 


<br>
<div class="ml10 mt2 mb5 mr10 sh">
		<span class="lblue "><div class="cntr"><span style="color: lime;"><b>Бонусы, бонусы, бонусы</b></span></div><br>
<div class="cntr"><span style="color: lime;">Сегодня всем игрокам:</span></div><br>
<br>
Бонусы клановых строений Х10
<div class="cntr"><span style="color: lime;">Уникальная возможность очень быстро прокачать своего персонажа и свой клан!</span></div><br>
<div class="cntr">  <img class="icon" height="50" src="/view/image/clan_bonuses/cb_arena_win.png"><img class="icon" height="50" src="http://144.76.125.123/view/image/item/herb10.png"><img class="icon" height="50" src="http://144.76.125.123//view/image/clan_bonuses/cb_arena_win.png"></div><br>
<br>
<div class="cntr"><span style="color: DarkGray;">Акция действует до 4 апреля включительно!</span></div><br>
</span>  <span style="display: inline"></span>
	</div>
	
         </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>


<br><div class="small mb2"> 
             <span class="fr rdmg"></span> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>';
echo '<br> <div class="cntr"> 
   <a href="/mail/1" class="ubtn inbl green mb5 mt-15"><span class="ul"><span class="ur">Купить золото</span></span></a>
  </div> ';
include ('./system/f.php');
/*
<center><font color=gold><b><img src=http://mrush.pw/image/artefact.png class=icon> 1 артефакт = 6руб</b></font></center><br>
<center><font color=gold><b><img src=http://144.76.125.123/view/image/item/book1.png class=icon> 1 книга новичка = 18руб</b></font></center><br>
<center><font color=gold><b><img src=http://144.76.125.123/view/image/item/book2.png class=icon> 1 книга драконоборца = 44руб</b></font></center><br>
<center><font color=gold><b><img src=http://144.76.125.123/view/image/item/book3.png class=icon> 1 книга мстителя = 89руб</b></font></center><br><br>
<center><font color=red><b>Минимально можно купить от 3 артефактов/книг, при покупке от 10 артефактов/книг, ещё 5 в подарок!</b></font></center><br>
*/
