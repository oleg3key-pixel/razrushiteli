<?
include './system/common.php';
include './system/functions.php';
include './system/user.php';
include './system/h.php';
echo '  <div class="ribbon mb2">
   <div class="rl">
    <div class="rr">
      Информация
    </div>
   </div>
  </div> 
  <div class="bdr bg_blue mb2 lyell">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="mt10 mlr10 mb5 win">
Раз ты здесь, то тебя волнуют надписи возле ника которые есть у некоторых игроков.<br><br>

<font color=red><i>(мд)</i></font> - Модератор игры!<br><br>
<font color=red><i>(сп)</i></font> - Поддержка игры!<br><br>
<font color=red><i>(адм)</i></font> - Администратор игры!<br><br>
<font color=red><i>(рзб)</i></font> - Разработчик игры!<br><br>
<font color=red><i>(соз)</i></font> - Верховный создатель игры!<br><br>
<font color=red><i>(фин)</i></font> - Финансовый помощник!<br><br>
<font color=red><i>(рек)</i></font> - Рекламодатель игры!<br><br>
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div> 
   <div>
    <div>
    </div>
   </div>
  </div> ';
include ('./system/f.php');