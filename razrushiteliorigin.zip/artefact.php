<?
include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';

include './system/h.php';












echo '  <div class="ribbon mb2">
   <div class="rl">
    <div class="rr">
      Бонусы донатеров
    </div>
   </div>
  </div> 
  <div class="bdr bg_blue mb2 lyell">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="mt10 mlr10 mb5 win">

           
    
           <div class="mt10 mlr10 mb5 win">
             <img src=/images/bonus/1.png class=icon> Книга атакера
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость книги составляет, <a>100руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Книга даёт бонус к атаке <a>+1000.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. книг: <a>30</a>
            <div class="mb2"></div> 
           </div>    
           
           
           <div class="mt10 mlr10 mb5 win">
             <img src=/view/image/bonus/2.png class=icon> Книга защитника
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость книги составляет, <a>100руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Книга даёт бонус к защите <a>+1000.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. книг: <a>30</a>
            <div class="mb2"></div> 
           </div>            
           
           
               <div class="mt10 mlr10 mb5 win">
             <img src=/view/image/bonus/3.png class=icon> Книга лекаря
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость книги составляет, <a>100руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Книга даёт бонус к здоровью <a>+1000.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. книг: <a>30</a>
            <div class="mb2"></div> 
           </div>       
           
           
 
 
 
            <div class="mt10 mlr10 mb5 win">
             <img src=/images/bonus/4.png class=icon> Свиток атаки
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость свитка составляет, <a>150руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Свиток даёт бонус к атаке <a>+2000.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. свитков: <a>30</a>
            <div class="mb2"></div> 
           </div>    
           
           
           <div class="mt10 mlr10 mb5 win">
             <img src=/view/image/bonus/5.png class=icon> Свиток защиты
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость свитка составляет, <a>150руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Свиток даёт бонус к защите <a>+2000.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. свитков: <a>30</a>
            <div class="mb2"></div> 
           </div>            
           
           
               <div class="mt10 mlr10 mb5 win">
             <img src=/view/image/bonus/6.png class=icon> Свиток здоровья
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость свитка составляет, <a>150руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Свиток даёт бонус к здоровью <a>+2000.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. свитков: <a>30</a>
            <div class="mb2"></div> 
           </div>       
 
 
 
 
                <div class="mt10 mlr10 mb5 win">
             <img src=/view/image/bonus/7.png class=icon> Книга опыта
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость книги составляет, <a>400руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Книга даёт бонус к опыту <a>+100%</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. книг: <a>10</a>
            <div class="mb2"></div> 
           </div>  
           
           
           
           
           
           
                <div class="mt10 mlr10 mb5 win">
             <img src=/view/image/bonus/8.png class=icon> Книга серебра
            <br>          

            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Стоимость книги составляет, <a>400руб.</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Книга даёт бонус к серебру <a>+100%</a>
            <div class="mb2"></div> 
            <span class="lorange"><img src=/view/image/icons/png/t1.png class=icon> Максимальное кол-во. книг: <a>10</a>
            <div class="mb2"></div> 
           </div>            
           
           
           
           
           
           
           
 
 
           
           
           
           <div class="mlr10 mb5 pb5"> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div> 
  </div> 
   <div>
    <div></div>
   </div>
  </div> ';








include ('./system/f.php');


