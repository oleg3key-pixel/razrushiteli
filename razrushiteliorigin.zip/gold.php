<?
include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';

include './system/h.php';












echo '  <div class="ribbon mb2">
   <div class="rl">
    <div class="rr">
      Бонусы донатеров
    </div>
   </div>
  </div> 
  <div class="bdr bg_blue mb2 lyell">
   <div class="wr1">
    <div class="wr2">
     <div class="wr3">
      <div class="wr4">
       <div class="wr5">
        <div class="wr6">
         <div class="wr7">
          <div class="wr8"> 
           <div class="mt10 mlr10 mb5 win">
<div class=cntr>
Донат на сумму 100руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=100&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 200руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=240&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 300руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=300&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 400руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=400&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 500руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=500&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 600руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=600&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 700руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=700&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 800руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=800&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 900руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=900&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>
<br><br>
Донат на сумму 1000руб
<iframe src="http://www.free-kassa.ru/merchant/forms.php?gen_form=1&targets=Покупка ресурсов!&default-sum=1000&button-text=Оплатить&button-size=s&encoding=CP1251&type=small&m=180381&id=737968"  width="320" height="100" frameBorder="0" target="_parent" ></iframe>





</div>                

           <div class="mlr10 mb5 pb5"> 
           </div> 
           <div class="clb"></div> 
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div> 
  </div> 
   <div>
    <div></div>
   </div>
  </div> ';








include ('./system/f.php');
/*swveh7nl
fk2su0lm*/

