<?php
    
include './system/common.php';   
include './system/functions.php'; 
include './system/user.php';
 $title = 'Донат';   
include './system/h.php'; 
?>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">
<center><font color=aqua><b>Донат через систему QIWI</b></font></center>
<center><font color=lime><b>Для получения ресурсов вам нужно выполнить следующие действия!<br><br>Перевести нужную сумму на номер<br><font color=orange>+79522513216</font><br>К комментарию добавить такой текст<br><font color=orange>( Пополнение от игрока: <?=$user['login']?> )</font></font></b></font></center>
	<div class="clb"></div>
</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">
<center><font color=aqua><b>Донат через систему VISA / MasterCard</b></font></center>
<center><font color=lime><b>Для получения ресурсов вам нужно выполнить следующие действия!<br><br>Перевести нужную сумму на номер<br><font color=orange>4890494696135409</font><br>К комментарию добавить такой текст<br><font color=orange>( Пополнение от игрока: <?=$user['login']?> )</font></font></b></font></center>
	<div class="clb"></div>
</div></div></div></div></div></div></div></div></div></div></div></div></div>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
	<div class="ml10 mt5 mr10 mb5 cntr">
<center><font color=aqua><b>Донат через систему YandexMoney</b></font></center>
<center><font color=lime><b>Для получения ресурсов вам нужно выполнить следующие действия!<br><br>Перевести нужную сумму на номер<br><font color=orange>410018534221517</font><br>К комментарию добавить такой текст<br><font color=orange>( Пополнение от игрока: <?=$user['login']?> )</font></font></center></div>
	<div class="clb"></div>
</div></div></div></div></div></div></div></div></div></div></div></div></div>
<div class="bdr bg_blue mb2"><div class="wr1"><div class="wr2"><div class="wr3"><div class="wr4"><div class="wr5"><div class="wr6"><div class="wr7"><div class="wr8">
<center><div class=block><font color=red>85руб. - 100.000 <img src=http://144.76.127.94/view/image/icons/gold.png class=icon><br>150руб. - 200.000 <img src=http://144.76.127.94/view/image/icons/gold.png class=icon><br>400руб. - 500.000 <img src=http://144.76.127.94/view/image/icons/gold.png class=icon><br>1000руб. - 1.500.000 <img src=http://144.76.127.94/view/image/icons/gold.png class=icon></b></font></div></center>
	<div class="clb"></div>
</div></div></div></div></div></div></div></div></div></div></div></div></div>
<div class="hr_g mb2"><div><div></div></div></div>
<a href="/lair_ob.php" class="mbtn mb2"><img class="icon" src="http://144.76.127.94/view/image/icons/gold.png"> Обменник</a>
<div class="hr_g mb2"><div><div></div></div></div>
<a href="/obmen.php" class="mbtn mb2"><img class="icon" src="http://144.76.127.94/view/image/icons/silver.png"> Купить серебро</a>
<?
include './system/f.php';
?>